-- ============================================================================
-- Remote Support Suite - Complete MySQL Database Schema (No Firebase)
-- Compatible with MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.4+
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- 1. Users table (Viewers, Support Agents, and Admins)
CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NULL,
    role ENUM('viewer', 'admin') NOT NULL DEFAULT 'viewer',
    api_token_hash CHAR(64) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    trial_started_at DATETIME NULL,
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_token (api_token_hash),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Devices table (Registered Host, Viewer, and Admin Android devices)
CREATE TABLE IF NOT EXISTS devices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_uid VARCHAR(100) NOT NULL UNIQUE,
    device_name VARCHAR(140) NOT NULL,
    device_model VARCHAR(120) NULL,
    os_version VARCHAR(60) NULL,
    app_role ENUM('host', 'viewer', 'admin') NOT NULL DEFAULT 'host',
    user_id BIGINT UNSIGNED NULL,
    network_type VARCHAR(32) NOT NULL DEFAULT 'unknown',
    is_online TINYINT(1) NOT NULL DEFAULT 1,
    last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(64) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_devices_role_seen (app_role, last_seen),
    INDEX idx_devices_user (user_id),
    CONSTRAINT fk_devices_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Support Sessions table (Session ID + temporary 6-digit PIN + Host consent state)
CREATE TABLE IF NOT EXISTS support_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_code VARCHAR(24) NOT NULL UNIQUE,
    pin_code CHAR(6) NOT NULL,
    pin_hash VARCHAR(255) NOT NULL,
    host_device_id BIGINT UNSIGNED NOT NULL,
    viewer_device_id BIGINT UNSIGNED NULL,
    viewer_user_id BIGINT UNSIGNED NULL,
    viewer_display_name VARCHAR(120) NULL,
    status ENUM('waiting', 'pending_approval', 'active', 'declined', 'ended', 'expired') NOT NULL DEFAULT 'waiting',
    quality_mode ENUM('high', 'balanced', 'low') NOT NULL DEFAULT 'balanced',
    assisted_control_enabled TINYINT(1) NOT NULL DEFAULT 1,
    end_reason VARCHAR(160) NULL,
    requested_at DATETIME NULL,
    accepted_at DATETIME NULL,
    ended_at DATETIME NULL,
    last_activity_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sessions_code_status (session_code, status),
    INDEX idx_sessions_host (host_device_id, status),
    INDEX idx_sessions_viewer_user (viewer_user_id, status),
    CONSTRAINT fk_sessions_host_device FOREIGN KEY (host_device_id) REFERENCES devices(id) ON DELETE CASCADE,
    CONSTRAINT fk_sessions_viewer_device FOREIGN KEY (viewer_device_id) REFERENCES devices(id) ON DELETE SET NULL,
    CONSTRAINT fk_sessions_viewer_user FOREIGN KEY (viewer_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Screen Frames and Remote Assisted Commands queue
CREATE TABLE IF NOT EXISTS screen_frames_and_commands (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_id BIGINT UNSIGNED NOT NULL,
    record_type ENUM('frame', 'command') NOT NULL,
    sender_role ENUM('host', 'viewer') NOT NULL,
    frame_base64 LONGTEXT NULL,
    frame_width INT UNSIGNED NULL,
    frame_height INT UNSIGNED NULL,
    frame_seq BIGINT UNSIGNED NULL,
    command_type ENUM('tap', 'swipe', 'home', 'back', 'recents', 'refresh', 'disconnect') NULL,
    payload_json TEXT NULL,
    is_processed TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sfc_session_type_id (session_id, record_type, id),
    INDEX idx_sfc_session_unprocessed (session_id, record_type, is_processed, id),
    CONSTRAINT fk_sfc_session FOREIGN KEY (session_id) REFERENCES support_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Subscription Plans table (Managed via SupportAdminConsole)
CREATE TABLE IF NOT EXISTS subscription_plans (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    description VARCHAR(255) NULL,
    price_amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(16) NOT NULL DEFAULT 'BDT',
    duration_days INT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_plans_active_sort (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. User Subscriptions table (Tracks 3-day free trial + verified paid plans)
CREATE TABLE IF NOT EXISTS user_subscriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    plan_id BIGINT UNSIGNED NULL,
    status ENUM('trial', 'active', 'pending_verification', 'expired', 'paused', 'revoked') NOT NULL DEFAULT 'trial',
    starts_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    updated_by_admin_id BIGINT UNSIGNED NULL,
    notes VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_subs_status_exp (status, expires_at),
    CONSTRAINT fk_user_subs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_user_subs_plan FOREIGN KEY (plan_id) REFERENCES subscription_plans(id) ON DELETE SET NULL,
    CONSTRAINT fk_user_subs_admin FOREIGN KEY (updated_by_admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Payment Methods table (bKash, Nagad, Rocket, Upay, Bank, USDT/Binance)
CREATE TABLE IF NOT EXISTS payment_methods (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    account_name VARCHAR(120) NOT NULL,
    account_number VARCHAR(160) NOT NULL,
    instructions TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_pm_active_sort (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Payment Requests table (Manual TrxID submission & Admin verification queue)
CREATE TABLE IF NOT EXISTS payment_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    plan_id BIGINT UNSIGNED NOT NULL,
    payment_method_id BIGINT UNSIGNED NOT NULL,
    sender_number VARCHAR(120) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(16) NOT NULL DEFAULT 'BDT',
    trx_id VARCHAR(120) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    admin_note VARCHAR(255) NULL,
    reviewed_by_admin_id BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_pr_status_created (status, created_at),
    INDEX idx_pr_user (user_id),
    UNIQUE KEY uq_payment_trx (payment_method_id, trx_id),
    CONSTRAINT fk_pr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_pr_plan FOREIGN KEY (plan_id) REFERENCES subscription_plans(id) ON DELETE RESTRICT,
    CONSTRAINT fk_pr_method FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    CONSTRAINT fk_pr_admin FOREIGN KEY (reviewed_by_admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. App Server Config table (Dynamic settings synced across Host, Viewer & Admin apps)
CREATE TABLE IF NOT EXISTS app_server_config (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(80) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    description VARCHAR(255) NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Initial Default Configuration & Seed Data (Idempotent)
-- ============================================================================

INSERT INTO app_server_config (config_key, config_value, description) VALUES
    ('base_api_url', 'https://your-domain.com/backend/api.php', 'Public base URL for PHP REST API'),
    ('frame_interval_ms', '650', 'Milliseconds between Host JPEG frame uploads'),
    ('command_poll_interval_ms', '350', 'Milliseconds between Host remote command polls'),
    ('default_trial_days', '3', 'Default free trial duration in days (72 hours)'),
    ('trial_enabled', '1', 'Whether automatic free trial is enabled for new viewers (1=yes, 0=no)'),
    ('api_secret_key', '', 'Optional shared X-API-Key secret managed from Admin Console'),
    ('app_update_notice', '', 'Optional announcement or update notice displayed in Host & Viewer apps')
ON DUPLICATE KEY UPDATE config_key = VALUES(config_key);

INSERT INTO subscription_plans (title, description, price_amount, currency, duration_days, is_active, sort_order)
SELECT 'Weekly Support Pass', 'Full screen viewer & assisted gesture support for 7 days', 199.00, 'BDT', 7, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM subscription_plans);

INSERT INTO subscription_plans (title, description, price_amount, currency, duration_days, is_active, sort_order)
SELECT 'Monthly Pro Support', 'Unlimited remote support sessions for 30 days', 499.00, 'BDT', 30, 1, 2
WHERE (SELECT COUNT(*) FROM subscription_plans) = 1;

INSERT INTO subscription_plans (title, description, price_amount, currency, duration_days, is_active, sort_order)
SELECT 'Quarterly Desk Plan', 'Best value 90-day support license', 1299.00, 'BDT', 90, 1, 3
WHERE (SELECT COUNT(*) FROM subscription_plans) = 2;

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'bKash', 'Remote Support Billing', '017XXXXXXXX', 'Send Money (Personal) and submit your 10-character TrxID.', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM payment_methods);

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'Nagad', 'Remote Support Billing', '018XXXXXXXX', 'Send Money (Personal) and enter your Nagad TrxID below.', 1, 2
WHERE (SELECT COUNT(*) FROM payment_methods) = 1;

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'Rocket', 'Remote Support Billing', '019XXXXXXXX', 'Send Money via DBBL Rocket and paste the Transaction ID.', 1, 3
WHERE (SELECT COUNT(*) FROM payment_methods) = 2;

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'Upay', 'Remote Support Billing', '016XXXXXXXX', 'Transfer exact amount via Upay and submit the TrxID.', 1, 4
WHERE (SELECT COUNT(*) FROM payment_methods) = 3;

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'Bank Transfer', 'Remote Support Desk Ltd.', 'AC: 0000-0000-0000 (Routing: 000000)', 'Transfer via BEFTN/NPSB and submit reference number as TrxID.', 1, 5
WHERE (SELECT COUNT(*) FROM payment_methods) = 4;

INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
SELECT 'USDT (Binance / TRC20)', 'Support Treasury', 'TXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', 'Send USDT (TRC20) or Binance Pay ID and submit TxHash/Order ID.', 1, 6
WHERE (SELECT COUNT(*) FROM payment_methods) = 5;
