# Remote Support Suite — PHP + MySQL Backend

100% Firebase-free REST & Polling backend serving:
1. **RemoteSupportHost** (App 1)
2. **RemoteSupportViewer** (App 2)
3. **SupportAdminConsole** (App 3)

## Quick Deployment (cPanel / VPS / XAMPP)

1. Create a MySQL database (e.g. `remote_support_db`) and import `backend/schema.sql`.
2. Create `backend/.env` beside `config.php` (never commit `.env` to version control):
   ```ini
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_NAME=remote_support_db
   DB_USER=your_db_user
   DB_PASS=your_db_password
   API_SECRET_KEY=
   CORS_ALLOWED_ORIGINS=
   ```
3. Upload `backend/config.php` and `backend/api.php` to your PHP 8.1+ web root (HTTPS recommended).
4. Test health:
   ```
   GET https://your-domain.com/backend/api.php?action=health
   ```
5. Initialize the first Admin account once via `POST ?action=admin_bootstrap` (automatically locks itself after the first admin is created).
6. Enter your `api.php` URL in **RemoteSupportHost -> Server Settings** and tap **Test & Sync**.
