<?php
declare(strict_types=1);

/**
 * Remote Support Suite - Complete PHP + MySQL JSON REST / Polling API
 *
 * Serves:
 *   - App 1: RemoteSupportHost
 *   - App 2: RemoteSupportViewer
 *   - App 3: SupportAdminConsole
 *
 * Security:
 *   - 100% PDO prepared statements
 *   - bcrypt password hashing + SHA-256 hashed Bearer API tokens
 *   - Server-side 3-day (72h) trial assignment & subscription expiry enforcement
 *   - Role-based access control for Admin Console CRUD endpoints
 *   - Zero Firebase dependencies
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

// Restricted CORS handling (configure CORS_ALLOWED_ORIGINS in backend/.env if accessed from web tools)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOriginsRaw = envValue('CORS_ALLOWED_ORIGINS', '');
if ($origin !== '' && $allowedOriginsRaw !== '') {
    $allowedOrigins = array_map('trim', explode(',', $allowedOriginsRaw));
    if (in_array($origin, $allowedOrigins, true)) {
        header("Access-Control-Allow-Origin: {$origin}");
        header('Vary: Origin');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const ONLINE_THRESHOLD_SECONDS = 45;
const MAX_FRAME_BASE64_BYTES = 1800000; // ~1.8 MB safety cap per compressed JPEG frame

function jsonResponse(array $payload, int $status = 200): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function errorResponse(string $code, string $message, int $status = 400, array $extra = []): never {
    jsonResponse(array_merge([
        'ok'      => false,
        'error'   => $code,
        'message' => $message,
    ], $extra), $status);
}

function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return $_POST;
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        errorResponse('invalid_json', 'Request body must be valid JSON.', 400);
    }
    return $decoded;
}

function getHeaderValue(string $name): string {
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    if (!empty($_SERVER[$serverKey])) {
        return trim((string) $_SERVER[$serverKey]);
    }
    if (function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strcasecmp($k, $name) === 0) {
                return trim((string) $v);
            }
        }
    }
    return '';
}

function getConfigMap(PDO $pdo): array {
    $stmt = $pdo->query('SELECT config_key, config_value FROM app_server_config');
    $map = [];
    foreach ($stmt->fetchAll() as $row) {
        $map[$row['config_key']] = (string) $row['config_value'];
    }
    return $map;
}

function verifyApiSecretIfConfigured(array $config): void {
    $expected = envValue('API_SECRET_KEY', $config['api_secret_key'] ?? '');
    if ($expected === '') {
        return;
    }
    $provided = getHeaderValue('X-API-Key');
    if ($provided === '' || !hash_equals($expected, $provided)) {
        errorResponse('invalid_api_key', 'Missing or invalid X-API-Key header.', 401);
    }
}

function getAuthenticatedUser(PDO $pdo): ?array {
    $auth = getHeaderValue('Authorization');
    if (!str_starts_with($auth, 'Bearer ')) {
        return null;
    }
    $token = trim(substr($auth, 7));
    if ($token === '') {
        return null;
    }
    $hash = hash('sha256', $token);
    $stmt = $pdo->prepare('SELECT id, email, full_name, phone, role, is_active, trial_started_at, created_at FROM users WHERE api_token_hash = ? LIMIT 1');
    $stmt->execute([$hash]);
    $user = $stmt->fetch();
    if (!$user || (int) $user['is_active'] !== 1) {
        return null;
    }
    return $user;
}

function requireUser(PDO $pdo): array {
    $user = getAuthenticatedUser($pdo);
    if ($user === null) {
        errorResponse('unauthorized', 'Valid Bearer token is required.', 401);
    }
    return $user;
}

function requireAdmin(PDO $pdo): array {
    $user = requireUser($pdo);
    if ($user['role'] !== 'admin') {
        errorResponse('forbidden', 'Administrator privileges are required.', 403);
    }
    return $user;
}

/**
 * Computes and enforces server-side subscription / 3-day trial status.
 * Automatically transitions expired trial/active rows to 'expired'.
 */
function evaluateUserSubscription(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare(
        'SELECT us.*, sp.title AS plan_title, sp.duration_days AS plan_duration_days, sp.price_amount AS plan_price
         FROM user_subscriptions us
         LEFT JOIN subscription_plans sp ON sp.id = us.plan_id
         WHERE us.user_id = ? LIMIT 1'
    );
    $stmt->execute([$userId]);
    $sub = $stmt->fetch();

    if (!$sub) {
        return [
            'status'            => 'expired',
            'is_entitled'       => false,
            'plan_id'           => null,
            'plan_title'        => null,
            'starts_at'         => null,
            'expires_at'        => null,
            'remaining_seconds' => 0,
            'remaining_days'    => 0,
            'has_pending_payment' => false,
        ];
    }

    $nowTs = time();
    $expTs = strtotime((string) $sub['expires_at'] . ' UTC') ?: 0;
    $status = (string) $sub['status'];

    if (in_array($status, ['trial', 'active'], true) && $expTs <= $nowTs) {
        $upd = $pdo->prepare("UPDATE user_subscriptions SET status = 'expired' WHERE id = ?");
        $upd->execute([$sub['id']]);
        $status = 'expired';
    }

    $pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM payment_requests WHERE user_id = ? AND status = 'pending'");
    $pendingStmt->execute([$userId]);
    $hasPending = ((int) $pendingStmt->fetchColumn()) > 0;

    $remainingSeconds = max(0, $expTs - $nowTs);
    $isEntitled = in_array($status, ['trial', 'active'], true) && $remainingSeconds > 0;
    $displayStatus = (!$isEntitled && $hasPending && $status === 'expired') ? 'pending_verification' : $status;

    return [
        'status'              => $displayStatus,
        'raw_status'          => $status,
        'is_entitled'         => $isEntitled,
        'plan_id'             => $sub['plan_id'] !== null ? (int) $sub['plan_id'] : null,
        'plan_title'          => $sub['plan_title'] ?: ($status === 'trial' ? '3-Day Free Trial' : null),
        'starts_at'           => $sub['starts_at'],
        'expires_at'          => $sub['expires_at'],
        'remaining_seconds'   => $remainingSeconds,
        'remaining_days'      => (int) ceil($remainingSeconds / 86400),
        'has_pending_payment' => $hasPending,
        'notes'               => $sub['notes'],
    ];
}

function generateSessionCode(): string {
    $a = random_int(100, 999);
    $b = random_int(100, 999);
    return sprintf('SUP-%03d-%03d', $a, $b);
}

function generateSixDigitPin(): string {
    return sprintf('%06d', random_int(100000, 999999));
}

function issueTokenForUser(PDO $pdo, int $userId): string {
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $stmt = $pdo->prepare('UPDATE users SET api_token_hash = ?, last_login_at = UTC_TIMESTAMP() WHERE id = ?');
    $stmt->execute([$hash, $userId]);
    return $token;
}

function cleanString(?string $v, int $maxLen = 255): string {
    $s = trim((string) ($v ?? ''));
    if (mb_strlen($s) > $maxLen) {
        $s = mb_substr($s, 0, $maxLen);
    }
    return $s;
}

try {
    $pdo = getDbConnection();
} catch (Throwable $e) {
    errorResponse('db_connection_failed', 'Database connection could not be established. Verify backend/.env credentials.', 503);
}

$config = getConfigMap($pdo);
$action = trim((string) ($_GET['action'] ?? 'health'));

// Health and public config remain accessible to test connectivity; protected endpoints check X-API-Key if set
if (!in_array($action, ['health', 'get_public_config'], true)) {
    verifyApiSecretIfConfigured($config);
}

$body = getJsonBody();

switch ($action) {
    // ========================================================================
    // 1. HEALTH & DYNAMIC PUBLIC CONFIG
    // ========================================================================
    case 'health': {
        $dbOk = false;
        try {
            $pdo->query('SELECT 1');
            $dbOk = true;
        } catch (Throwable $e) {
            $dbOk = false;
        }
        $adminCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
        jsonResponse([
            'ok'                     => true,
            'status'                 => $dbOk ? 'online' : 'degraded',
            'database_connected'     => $dbOk,
            'server_time_utc'        => gmdate('Y-m-d H:i:s'),
            'admin_initialized'      => $adminCount > 0,
            'api_secret_required'    => envValue('API_SECRET_KEY', $config['api_secret_key'] ?? '') !== '',
            'frame_interval_ms'      => max(250, (int) ($config['frame_interval_ms'] ?? 650)),
            'command_poll_interval_ms' => max(200, (int) ($config['command_poll_interval_ms'] ?? 350)),
            'default_trial_days'     => max(0, (int) ($config['default_trial_days'] ?? 3)),
            'trial_enabled'          => ($config['trial_enabled'] ?? '1') === '1',
            'app_update_notice'      => (string) ($config['app_update_notice'] ?? ''),
        ]);
    }

    case 'get_public_config': {
        jsonResponse([
            'ok'                       => true,
            'base_api_url'             => (string) ($config['base_api_url'] ?? ''),
            'frame_interval_ms'        => max(250, (int) ($config['frame_interval_ms'] ?? 650)),
            'command_poll_interval_ms' => max(200, (int) ($config['command_poll_interval_ms'] ?? 350)),
            'default_trial_days'       => max(0, (int) ($config['default_trial_days'] ?? 3)),
            'trial_enabled'            => ($config['trial_enabled'] ?? '1') === '1',
            'app_update_notice'        => (string) ($config['app_update_notice'] ?? ''),
        ]);
    }

    // ========================================================================
    // 2. AUTHENTICATION & AUTOMATIC 3-DAY (72H) FREE TRIAL
    // ========================================================================
    case 'admin_bootstrap': {
        $adminCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
        if ($adminCount > 0) {
            errorResponse('admin_already_exists', 'An admin account has already been initialized.', 409);
        }
        $email = strtolower(cleanString($body['email'] ?? '', 190));
        $password = (string) ($body['password'] ?? '');
        $fullName = cleanString($body['full_name'] ?? 'Master Admin', 120);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            errorResponse('invalid_email', 'Provide a valid admin email address.', 422);
        }
        if (strlen($password) < 8) {
            errorResponse('weak_password', 'Admin password must be at least 8 characters.', 422);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'admin', 1)");
        $stmt->execute([$email, $hash, $fullName]);
        $userId = (int) $pdo->lastInsertId();
        $token = issueTokenForUser($pdo, $userId);

        jsonResponse([
            'ok'    => true,
            'token' => $token,
            'user'  => [
                'id'        => $userId,
                'email'     => $email,
                'full_name' => $fullName,
                'role'      => 'admin',
            ],
        ], 201);
    }

    case 'register': {
        $email = strtolower(cleanString($body['email'] ?? '', 190));
        $password = (string) ($body['password'] ?? '');
        $fullName = cleanString($body['full_name'] ?? '', 120);
        $phone = cleanString($body['phone'] ?? '', 40);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            errorResponse('invalid_email', 'Please enter a valid email address.', 422);
        }
        if (strlen($password) < 6) {
            errorResponse('weak_password', 'Password must be at least 6 characters.', 422);
        }
        if ($fullName === '') {
            $fullName = explode('@', $email)[0];
        }

        $existsStmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $existsStmt->execute([$email]);
        if ($existsStmt->fetch()) {
            errorResponse('email_exists', 'An account with this email already exists.', 409);
        }

        $trialEnabled = ($config['trial_enabled'] ?? '1') === '1';
        $trialDays = max(0, (int) ($config['default_trial_days'] ?? 3));

        $pdo->beginTransaction();
        try {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $insUser = $pdo->prepare(
                "INSERT INTO users (email, password_hash, full_name, phone, role, is_active, trial_started_at)
                 VALUES (?, ?, ?, ?, 'viewer', 1, UTC_TIMESTAMP())"
            );
            $insUser->execute([$email, $hash, $fullName, $phone !== '' ? $phone : null]);
            $userId = (int) $pdo->lastInsertId();

            // Assign automatic 3-day (72h) free trial if enabled
            $subStatus = ($trialEnabled && $trialDays > 0) ? 'trial' : 'expired';
            $expiresAt = ($trialEnabled && $trialDays > 0)
                ? gmdate('Y-m-d H:i:s', time() + ($trialDays * 86400))
                : gmdate('Y-m-d H:i:s');

            $insSub = $pdo->prepare(
                'INSERT INTO user_subscriptions (user_id, plan_id, status, starts_at, expires_at, notes)
                 VALUES (?, NULL, ?, UTC_TIMESTAMP(), ?, ?)'
            );
            $insSub->execute([
                $userId,
                $subStatus,
                $expiresAt,
                $trialEnabled ? "Automatic {$trialDays}-day free trial" : 'Trial disabled by admin',
            ]);

            $token = issueTokenForUser($pdo, $userId);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            errorResponse('register_failed', 'Could not create account.', 500);
        }

        jsonResponse([
            'ok'           => true,
            'token'        => $token,
            'user'         => [
                'id'        => $userId,
                'email'     => $email,
                'full_name' => $fullName,
                'phone'     => $phone,
                'role'      => 'viewer',
            ],
            'subscription' => evaluateUserSubscription($pdo, $userId),
        ], 201);
    }

    case 'login': {
        $email = strtolower(cleanString($body['email'] ?? '', 190));
        $password = (string) ($body['password'] ?? '');

        $stmt = $pdo->prepare('SELECT id, email, password_hash, full_name, phone, role, is_active FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, (string) $user['password_hash'])) {
            errorResponse('invalid_credentials', 'Invalid email or password.', 401);
        }
        if ((int) $user['is_active'] !== 1) {
            errorResponse('account_disabled', 'This account has been suspended by an administrator.', 403);
        }

        $token = issueTokenForUser($pdo, (int) $user['id']);
        jsonResponse([
            'ok'           => true,
            'token'        => $token,
            'user'         => [
                'id'        => (int) $user['id'],
                'email'     => $user['email'],
                'full_name' => $user['full_name'],
                'phone'     => $user['phone'],
                'role'      => $user['role'],
            ],
            'subscription' => $user['role'] === 'viewer' ? evaluateUserSubscription($pdo, (int) $user['id']) : null,
        ]);
    }

    case 'me': {
        $user = requireUser($pdo);
        jsonResponse([
            'ok'           => true,
            'user'         => [
                'id'        => (int) $user['id'],
                'email'     => $user['email'],
                'full_name' => $user['full_name'],
                'phone'     => $user['phone'],
                'role'      => $user['role'],
            ],
            'subscription' => $user['role'] === 'viewer' ? evaluateUserSubscription($pdo, (int) $user['id']) : null,
        ]);
    }

    // ========================================================================
    // 3. DEVICE REGISTRATION, HEARTBEAT & ONLINE/OFFLINE STATUS
    // ========================================================================
    case 'register_device': {
        $deviceUid = cleanString($body['device_uid'] ?? '', 100);
        $deviceName = cleanString($body['device_name'] ?? 'Android Device', 140);
        $deviceModel = cleanString($body['device_model'] ?? '', 120);
        $osVersion = cleanString($body['os_version'] ?? '', 60);
        $appRole = cleanString($body['app_role'] ?? 'host', 16);
        $networkType = cleanString($body['network_type'] ?? 'wifi', 32);

        if ($deviceUid === '') {
            errorResponse('missing_device_uid', 'device_uid is required.', 422);
        }
        if (!in_array($appRole, ['host', 'viewer', 'admin'], true)) {
            $appRole = 'host';
        }

        $authUser = getAuthenticatedUser($pdo);
        $userId = $authUser ? (int) $authUser['id'] : null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;

        $stmt = $pdo->prepare(
            'INSERT INTO devices (device_uid, device_name, device_model, os_version, app_role, user_id, network_type, is_online, last_seen, ip_address)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1, UTC_TIMESTAMP(), ?)
             ON DUPLICATE KEY UPDATE
               device_name = VALUES(device_name),
               device_model = VALUES(device_model),
               os_version = VALUES(os_version),
               app_role = VALUES(app_role),
               user_id = COALESCE(VALUES(user_id), user_id),
               network_type = VALUES(network_type),
               is_online = 1,
               last_seen = UTC_TIMESTAMP(),
               ip_address = VALUES(ip_address)'
        );
        $stmt->execute([$deviceUid, $deviceName, $deviceModel, $osVersion, $appRole, $userId, $networkType, $ip]);

        $sel = $pdo->prepare('SELECT id, device_uid, device_name, app_role, is_online, last_seen FROM devices WHERE device_uid = ? LIMIT 1');
        $sel->execute([$deviceUid]);
        $device = $sel->fetch();

        jsonResponse([
            'ok'     => true,
            'device' => $device,
            'config' => [
                'frame_interval_ms'        => max(250, (int) ($config['frame_interval_ms'] ?? 650)),
                'command_poll_interval_ms' => max(200, (int) ($config['command_poll_interval_ms'] ?? 350)),
                'app_update_notice'        => (string) ($config['app_update_notice'] ?? ''),
            ],
        ]);
    }

    case 'heartbeat': {
        $deviceUid = cleanString($body['device_uid'] ?? '', 100);
        $networkType = cleanString($body['network_type'] ?? 'unknown', 32);
        if ($deviceUid === '') {
            errorResponse('missing_device_uid', 'device_uid is required.', 422);
        }

        $upd = $pdo->prepare('UPDATE devices SET is_online = 1, network_type = ?, last_seen = UTC_TIMESTAMP(), ip_address = ? WHERE device_uid = ?');
        $upd->execute([$networkType, $_SERVER['REMOTE_ADDR'] ?? null, $deviceUid]);

        jsonResponse([
            'ok'                       => true,
            'server_time_utc'          => gmdate('Y-m-d H:i:s'),
            'frame_interval_ms'        => max(250, (int) ($config['frame_interval_ms'] ?? 650)),
            'command_poll_interval_ms' => max(200, (int) ($config['command_poll_interval_ms'] ?? 350)),
            'app_update_notice'        => (string) ($config['app_update_notice'] ?? ''),
        ]);
    }

    case 'device_status': {
        $deviceUid = cleanString($_GET['device_uid'] ?? ($body['device_uid'] ?? ''), 100);
        if ($deviceUid === '') {
            errorResponse('missing_device_uid', 'device_uid is required.', 422);
        }
        $stmt = $pdo->prepare(
            'SELECT id, device_uid, device_name, app_role, network_type, last_seen,
                    (TIMESTAMPDIFF(SECOND, last_seen, UTC_TIMESTAMP()) <= ?) AS is_online_now
             FROM devices WHERE device_uid = ? LIMIT 1'
        );
        $stmt->execute([ONLINE_THRESHOLD_SECONDS, $deviceUid]);
        $dev = $stmt->fetch();
        if (!$dev) {
            errorResponse('device_not_found', 'Device is not registered.', 404);
        }
        jsonResponse([
            'ok'          => true,
            'device_uid'  => $dev['device_uid'],
            'device_name' => $dev['device_name'],
            'app_role'    => $dev['app_role'],
            'network_type'=> $dev['network_type'],
            'is_online'   => ((int) $dev['is_online_now']) === 1,
            'last_seen'   => $dev['last_seen'],
        ]);
    }

    // ========================================================================
    // 4. SUPPORT SESSION PAIRING & EXPLICIT HOST ACCEPT / DECLINE
    // ========================================================================
    case 'create_session': {
        $deviceUid = cleanString($body['device_uid'] ?? '', 100);
        if ($deviceUid === '') {
            errorResponse('missing_device_uid', 'Host device_uid is required.', 422);
        }

        $devStmt = $pdo->prepare('SELECT id, device_name FROM devices WHERE device_uid = ? LIMIT 1');
        $devStmt->execute([$deviceUid]);
        $hostDev = $devStmt->fetch();
        if (!$hostDev) {
            errorResponse('device_not_found', 'Register host device before creating a session.', 404);
        }

        // End any stale waiting/pending sessions for this host device
        $closeOld = $pdo->prepare(
            "UPDATE support_sessions SET status = 'ended', ended_at = UTC_TIMESTAMP(), end_reason = 'Superseded by new session'
             WHERE host_device_id = ? AND status IN ('waiting', 'pending_approval', 'active')"
        );
        $closeOld->execute([$hostDev['id']]);

        $sessionCode = generateSessionCode();
        for ($i = 0; $i < 5; $i++) {
            $chk = $pdo->prepare('SELECT id FROM support_sessions WHERE session_code = ? LIMIT 1');
            $chk->execute([$sessionCode]);
            if (!$chk->fetch()) {
                break;
            }
            $sessionCode = generateSessionCode();
        }
        $pin = generateSixDigitPin();
        $pinHash = password_hash($pin, PASSWORD_BCRYPT);

        $ins = $pdo->prepare(
            "INSERT INTO support_sessions (session_code, pin_code, pin_hash, host_device_id, status, quality_mode, last_activity_at)
             VALUES (?, ?, ?, ?, 'waiting', 'balanced', UTC_TIMESTAMP())"
        );
        $ins->execute([$sessionCode, $pin, $pinHash, $hostDev['id']]);
        $sessionId = (int) $pdo->lastInsertId();

        jsonResponse([
            'ok'           => true,
            'session_id'   => $sessionId,
            'session_code' => $sessionCode,
            'pin_code'     => $pin,
            'status'       => 'waiting',
            'quality_mode' => 'balanced',
        ], 201);
    }

    case 'request_connection': {
        $viewer = requireUser($pdo);
        $sub = evaluateUserSubscription($pdo, (int) $viewer['id']);
        if ($viewer['role'] !== 'admin' && !$sub['is_entitled']) {
            errorResponse(
                'subscription_expired',
                'Your 3-day free trial or subscription has expired. Please renew to connect.',
                403,
                ['subscription' => $sub]
            );
        }

        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $pin = cleanString($body['pin_code'] ?? '', 12);
        $viewerDeviceUid = cleanString($body['viewer_device_uid'] ?? '', 100);

        if ($sessionCode === '' || $pin === '') {
            errorResponse('missing_pairing_credentials', 'Session ID and 6-digit PIN are required.', 422);
        }

        $stmt = $pdo->prepare(
            'SELECT ss.*, d.device_name AS host_device_name,
                    (TIMESTAMPDIFF(SECOND, d.last_seen, UTC_TIMESTAMP()) <= ?) AS host_online
             FROM support_sessions ss
             JOIN devices d ON d.id = ss.host_device_id
             WHERE ss.session_code = ? LIMIT 1'
        );
        $stmt->execute([ONLINE_THRESHOLD_SECONDS, $sessionCode]);
        $session = $stmt->fetch();

        if (!$session) {
            errorResponse('session_not_found', 'No support session matches that Session ID.', 404);
        }
        if (!in_array($session['status'], ['waiting', 'pending_approval'], true)) {
            errorResponse('session_unavailable', "Session is currently {$session['status']}.", 409);
        }
        if (!password_verify($pin, (string) $session['pin_hash'])) {
            errorResponse('invalid_pin', 'The 6-digit PIN is incorrect.', 403);
        }

        $viewerDevId = null;
        if ($viewerDeviceUid !== '') {
            $vd = $pdo->prepare('SELECT id FROM devices WHERE device_uid = ? LIMIT 1');
            $vd->execute([$viewerDeviceUid]);
            $row = $vd->fetch();
            if ($row) {
                $viewerDevId = (int) $row['id'];
            }
        }

        $upd = $pdo->prepare(
            "UPDATE support_sessions
             SET viewer_user_id = ?, viewer_device_id = ?, viewer_display_name = ?,
                 status = 'pending_approval', requested_at = UTC_TIMESTAMP(), last_activity_at = UTC_TIMESTAMP()
             WHERE id = ?"
        );
        $upd->execute([$viewer['id'], $viewerDevId, $viewer['full_name'], $session['id']]);

        jsonResponse([
            'ok'               => true,
            'session_id'       => (int) $session['id'],
            'session_code'     => $session['session_code'],
            'host_device_name' => $session['host_device_name'],
            'host_online'      => ((int) $session['host_online']) === 1,
            'status'           => 'pending_approval',
            'subscription'     => $sub,
        ]);
    }

    case 'session_status': {
        $sessionCode = strtoupper(cleanString($_GET['session_code'] ?? ($body['session_code'] ?? ''), 24));
        if ($sessionCode === '') {
            errorResponse('missing_session_code', 'session_code is required.', 422);
        }

        $stmt = $pdo->prepare(
            'SELECT ss.*, hd.device_uid AS host_device_uid, hd.device_name AS host_device_name,
                    (TIMESTAMPDIFF(SECOND, hd.last_seen, UTC_TIMESTAMP()) <= ?) AS host_online,
                    vu.email AS viewer_email, vu.full_name AS viewer_full_name, vu.role AS viewer_role
             FROM support_sessions ss
             JOIN devices hd ON hd.id = ss.host_device_id
             LEFT JOIN users vu ON vu.id = ss.viewer_user_id
             WHERE ss.session_code = ? LIMIT 1'
        );
        $stmt->execute([ONLINE_THRESHOLD_SECONDS, $sessionCode]);
        $session = $stmt->fetch();
        if (!$session) {
            errorResponse('session_not_found', 'Session not found.', 404);
        }

        $viewerSub = null;
        $viewerEntitled = false;
        if ($session['viewer_user_id'] !== null) {
            if ($session['viewer_role'] === 'admin') {
                $viewerEntitled = true;
                $viewerSub = [
                    'status'            => 'active',
                    'is_entitled'       => true,
                    'plan_title'        => 'Admin Console',
                    'remaining_seconds' => 9999999,
                    'remaining_days'    => 999,
                ];
            } else {
                $viewerSub = evaluateUserSubscription($pdo, (int) $session['viewer_user_id']);
                $viewerEntitled = (bool) $viewerSub['is_entitled'];
                // Auto-expire active session if viewer subscription expired mid-session
                if (!$viewerEntitled && $session['status'] === 'active') {
                    $expUpd = $pdo->prepare(
                        "UPDATE support_sessions SET status = 'expired', ended_at = UTC_TIMESTAMP(),
                         end_reason = 'Controller trial or subscription expired' WHERE id = ?"
                    );
                    $expUpd->execute([$session['id']]);
                    $session['status'] = 'expired';
                    $session['end_reason'] = 'Controller trial or subscription expired';
                }
            }
        }

        jsonResponse([
            'ok'                       => true,
            'session_id'               => (int) $session['id'],
            'session_code'             => $session['session_code'],
            'status'                   => $session['status'],
            'quality_mode'             => $session['quality_mode'],
            'assisted_control_enabled' => ((int) $session['assisted_control_enabled']) === 1,
            'host_device_name'         => $session['host_device_name'],
            'host_online'              => ((int) $session['host_online']) === 1,
            'viewer_name'              => $session['viewer_display_name'] ?: $session['viewer_full_name'],
            'viewer_email'             => $session['viewer_email'],
            'viewer_entitled'          => $viewerEntitled,
            'viewer_subscription'      => $viewerSub,
            'end_reason'               => $session['end_reason'],
            'requested_at'             => $session['requested_at'],
            'accepted_at'              => $session['accepted_at'],
            'frame_interval_ms'        => max(250, (int) ($config['frame_interval_ms'] ?? 650)),
            'command_poll_interval_ms' => max(200, (int) ($config['command_poll_interval_ms'] ?? 350)),
        ]);
    }

    case 'respond_connection': {
        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $deviceUid = cleanString($body['device_uid'] ?? '', 100);
        $decision = strtolower(cleanString($body['decision'] ?? '', 16)); // accept | decline
        $assistedEnabled = isset($body['assisted_control_enabled']) ? ((bool) $body['assisted_control_enabled'] ? 1 : 0) : 1;

        if ($sessionCode === '' || $deviceUid === '' || !in_array($decision, ['accept', 'decline'], true)) {
            errorResponse('invalid_parameters', 'session_code, device_uid, and decision (accept/decline) are required.', 422);
        }

        $stmt = $pdo->prepare(
            'SELECT ss.*, hd.device_uid AS host_device_uid, vu.role AS viewer_role
             FROM support_sessions ss
             JOIN devices hd ON hd.id = ss.host_device_id
             LEFT JOIN users vu ON vu.id = ss.viewer_user_id
             WHERE ss.session_code = ? LIMIT 1'
        );
        $stmt->execute([$sessionCode]);
        $session = $stmt->fetch();
        if (!$session) {
            errorResponse('session_not_found', 'Session not found.', 404);
        }
        if ($session['host_device_uid'] !== $deviceUid) {
            errorResponse('forbidden', 'Only the owning Host device can respond to this request.', 403);
        }
        if ($session['status'] !== 'pending_approval') {
            errorResponse('invalid_state', 'No pending approval request for this session.', 409);
        }

        if ($decision === 'accept') {
            if ($session['viewer_user_id'] !== null && $session['viewer_role'] !== 'admin') {
                $sub = evaluateUserSubscription($pdo, (int) $session['viewer_user_id']);
                if (!$sub['is_entitled']) {
                    errorResponse('subscription_expired', 'Viewer trial or subscription is no longer active.', 403);
                }
            }
            $upd = $pdo->prepare(
                "UPDATE support_sessions
                 SET status = 'active', assisted_control_enabled = ?, accepted_at = UTC_TIMESTAMP(), last_activity_at = UTC_TIMESTAMP()
                 WHERE id = ?"
            );
            $upd->execute([$assistedEnabled, $session['id']]);
            jsonResponse([
                'ok'           => true,
                'session_code' => $sessionCode,
                'status'       => 'active',
            ]);
        } else {
            $upd = $pdo->prepare(
                "UPDATE support_sessions
                 SET status = 'declined', ended_at = UTC_TIMESTAMP(), end_reason = 'Declined by Host user'
                 WHERE id = ?"
            );
            $upd->execute([$session['id']]);
            jsonResponse([
                'ok'           => true,
                'session_code' => $sessionCode,
                'status'       => 'declined',
            ]);
        }
    }

    case 'update_session_settings': {
        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $quality = strtolower(cleanString($body['quality_mode'] ?? '', 16));
        $assisted = isset($body['assisted_control_enabled']) ? ((bool) $body['assisted_control_enabled'] ? 1 : 0) : null;

        if ($sessionCode === '') {
            errorResponse('missing_session_code', 'session_code is required.', 422);
        }
        if ($quality !== '' && !in_array($quality, ['high', 'balanced', 'low'], true)) {
            errorResponse('invalid_quality', 'quality_mode must be high, balanced, or low.', 422);
        }

        if ($quality !== '' && $assisted !== null) {
            $upd = $pdo->prepare('UPDATE support_sessions SET quality_mode = ?, assisted_control_enabled = ?, last_activity_at = UTC_TIMESTAMP() WHERE session_code = ?');
            $upd->execute([$quality, $assisted, $sessionCode]);
        } elseif ($quality !== '') {
            $upd = $pdo->prepare('UPDATE support_sessions SET quality_mode = ?, last_activity_at = UTC_TIMESTAMP() WHERE session_code = ?');
            $upd->execute([$quality, $sessionCode]);
        } elseif ($assisted !== null) {
            $upd = $pdo->prepare('UPDATE support_sessions SET assisted_control_enabled = ?, last_activity_at = UTC_TIMESTAMP() WHERE session_code = ?');
            $upd->execute([$assisted, $sessionCode]);
        }

        jsonResponse(['ok' => true, 'session_code' => $sessionCode]);
    }

    case 'end_session': {
        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $reason = cleanString($body['reason'] ?? 'Ended by user', 160);
        if ($sessionCode === '') {
            errorResponse('missing_session_code', 'session_code is required.', 422);
        }

        $upd = $pdo->prepare(
            "UPDATE support_sessions SET status = 'ended', ended_at = UTC_TIMESTAMP(), end_reason = ? WHERE session_code = ?"
        );
        $upd->execute([$reason, $sessionCode]);
        jsonResponse(['ok' => true, 'session_code' => $sessionCode, 'status' => 'ended']);
    }

    // ========================================================================
    // 5. REAL-TIME SCREEN FRAMES & REMOTE COMMAND QUEUE
    // ========================================================================
    case 'upload_frame': {
        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $deviceUid = cleanString($body['device_uid'] ?? '', 100);
        $frameBase64 = (string) ($body['frame_base64'] ?? '');
        $width = max(1, (int) ($body['width'] ?? 720));
        $height = max(1, (int) ($body['height'] ?? 1280));
        $seq = max(1, (int) ($body['frame_seq'] ?? 1));

        if ($sessionCode === '' || $deviceUid === '' || $frameBase64 === '') {
            errorResponse('missing_frame_data', 'session_code, device_uid, and frame_base64 are required.', 422);
        }
        if (strlen($frameBase64) > MAX_FRAME_BASE64_BYTES) {
            errorResponse('frame_too_large', 'Frame payload exceeds maximum allowed size.', 413);
        }

        $stmt = $pdo->prepare(
            'SELECT ss.id, ss.status, ss.viewer_user_id, ss.quality_mode, hd.device_uid AS host_device_uid, vu.role AS viewer_role
             FROM support_sessions ss
             JOIN devices hd ON hd.id = ss.host_device_id
             LEFT JOIN users vu ON vu.id = ss.viewer_user_id
             WHERE ss.session_code = ? LIMIT 1'
        );
        $stmt->execute([$sessionCode]);
        $session = $stmt->fetch();

        if (!$session || $session['host_device_uid'] !== $deviceUid) {
            errorResponse('forbidden', 'Invalid session or host device.', 403);
        }
        if ($session['status'] !== 'active') {
            errorResponse('session_inactive', "Session is {$session['status']}.", 409, ['session_status' => $session['status']]);
        }

        // Enforce paired Controller active trial or subscription on every frame upload
        if ($session['viewer_user_id'] !== null && $session['viewer_role'] !== 'admin') {
            $sub = evaluateUserSubscription($pdo, (int) $session['viewer_user_id']);
            if (!$sub['is_entitled']) {
                $pdo->prepare("UPDATE support_sessions SET status = 'expired', ended_at = UTC_TIMESTAMP(), end_reason = 'Controller subscription expired' WHERE id = ?")
                    ->execute([$session['id']]);
                errorResponse('subscription_expired', 'Paired Controller trial or subscription expired.', 403);
            }
        }

        $ins = $pdo->prepare(
            "INSERT INTO screen_frames_and_commands (session_id, record_type, sender_role, frame_base64, frame_width, frame_height, frame_seq)
             VALUES (?, 'frame', 'host', ?, ?, ?, ?)"
        );
        $ins->execute([$session['id'], $frameBase64, $width, $height, $seq]);
        $frameId = (int) $pdo->lastInsertId();

        // Prune older frames to keep MySQL fast and compact (retain latest 3 frames)
        $prune = $pdo->prepare(
            "DELETE FROM screen_frames_and_commands
             WHERE session_id = ? AND record_type = 'frame' AND id < ?"
        );
        $prune->execute([$session['id'], max(0, $frameId - 2)]);

        $pdo->prepare('UPDATE support_sessions SET last_activity_at = UTC_TIMESTAMP() WHERE id = ?')
            ->execute([$session['id']]);

        jsonResponse([
            'ok'           => true,
            'frame_id'     => $frameId,
            'quality_mode' => $session['quality_mode'],
            'status'       => 'active',
        ]);
    }

    case 'fetch_frame': {
        $viewer = requireUser($pdo);
        if ($viewer['role'] !== 'admin') {
            $sub = evaluateUserSubscription($pdo, (int) $viewer['id']);
            if (!$sub['is_entitled']) {
                errorResponse('subscription_expired', 'Trial or subscription expired. Renew to continue viewing.', 403, ['subscription' => $sub]);
            }
        }

        $sessionCode = strtoupper(cleanString($_GET['session_code'] ?? ($body['session_code'] ?? ''), 24));
        $afterId = max(0, (int) ($_GET['after_id'] ?? ($body['after_id'] ?? 0)));

        $stmt = $pdo->prepare('SELECT id, status, viewer_user_id, quality_mode, end_reason FROM support_sessions WHERE session_code = ? LIMIT 1');
        $stmt->execute([$sessionCode]);
        $session = $stmt->fetch();
        if (!$session || ($viewer['role'] !== 'admin' && (int) $session['viewer_user_id'] !== (int) $viewer['id'])) {
            errorResponse('forbidden', 'You are not paired with this support session.', 403);
        }

        $fStmt = $pdo->prepare(
            "SELECT id, frame_base64, frame_width, frame_height, frame_seq, created_at
             FROM screen_frames_and_commands
             WHERE session_id = ? AND record_type = 'frame' AND id > ?
             ORDER BY id DESC LIMIT 1"
        );
        $fStmt->execute([$session['id'], $afterId]);
        $frame = $fStmt->fetch();

        jsonResponse([
            'ok'             => true,
            'session_status' => $session['status'],
            'quality_mode'   => $session['quality_mode'],
            'end_reason'     => $session['end_reason'],
            'has_new_frame'  => $frame !== false,
            'frame'          => $frame ?: null,
        ]);
    }

    case 'send_command': {
        $viewer = requireUser($pdo);
        if ($viewer['role'] !== 'admin') {
            $sub = evaluateUserSubscription($pdo, (int) $viewer['id']);
            if (!$sub['is_entitled']) {
                errorResponse('subscription_expired', 'Active trial or subscription is required to send remote commands.', 403);
            }
        }

        $sessionCode = strtoupper(cleanString($body['session_code'] ?? '', 24));
        $commandType = strtolower(cleanString($body['command_type'] ?? '', 24));
        $payload = is_array($body['payload'] ?? null) ? $body['payload'] : [];

        $allowedCommands = ['tap', 'swipe', 'home', 'back', 'recents', 'refresh', 'disconnect'];
        if (!in_array($commandType, $allowedCommands, true)) {
            errorResponse('invalid_command', 'Unsupported command_type.', 422);
        }

        $stmt = $pdo->prepare('SELECT id, status, viewer_user_id, assisted_control_enabled FROM support_sessions WHERE session_code = ? LIMIT 1');
        $stmt->execute([$sessionCode]);
        $session = $stmt->fetch();
        if (!$session || ($viewer['role'] !== 'admin' && (int) $session['viewer_user_id'] !== (int) $viewer['id'])) {
            errorResponse('forbidden', 'Not authorized for this session.', 403);
        }
        if ($session['status'] !== 'active') {
            errorResponse('session_inactive', "Session is {$session['status']}.", 409);
        }

        // Sanitize normalized coordinates (0.0 - 1.0)
        $cleanPayload = [];
        if ($commandType === 'tap') {
            $cleanPayload['x'] = max(0.0, min(1.0, (float) ($payload['x'] ?? 0.5)));
            $cleanPayload['y'] = max(0.0, min(1.0, (float) ($payload['y'] ?? 0.5)));
        } elseif ($commandType === 'swipe') {
            $cleanPayload['x1'] = max(0.0, min(1.0, (float) ($payload['x1'] ?? 0.5)));
            $cleanPayload['y1'] = max(0.0, min(1.0, (float) ($payload['y1'] ?? 0.5)));
            $cleanPayload['x2'] = max(0.0, min(1.0, (float) ($payload['x2'] ?? 0.5)));
            $cleanPayload['y2'] = max(0.0, min(1.0, (float) ($payload['y2'] ?? 0.5)));
            $cleanPayload['duration_ms'] = max(80, min(1500, (int) ($payload['duration_ms'] ?? 280)));
        }

        $ins = $pdo->prepare(
            "INSERT INTO screen_frames_and_commands (session_id, record_type, sender_role, command_type, payload_json, is_processed)
             VALUES (?, 'command', 'viewer', ?, ?, 0)"
        );
        $ins->execute([$session['id'], $commandType, json_encode($cleanPayload)]);

        if ($commandType === 'disconnect') {
            $pdo->prepare("UPDATE support_sessions SET status = 'ended', ended_at = UTC_TIMESTAMP(), end_reason = 'Disconnected by Controller' WHERE id = ?")
                ->execute([$session['id']]);
        }

        jsonResponse([
            'ok'         => true,
            'command_id' => (int) $pdo->lastInsertId(),
        ]);
    }

    case 'poll_commands': {
        $sessionCode = strtoupper(cleanString($_GET['session_code'] ?? ($body['session_code'] ?? ''), 24));
        $deviceUid = cleanString($_GET['device_uid'] ?? ($body['device_uid'] ?? ''), 100);

        $stmt = $pdo->prepare(
            'SELECT ss.id, ss.status, ss.quality_mode, ss.assisted_control_enabled, ss.viewer_user_id,
                    hd.device_uid AS host_device_uid, vu.role AS viewer_role
             FROM support_sessions ss
             JOIN devices hd ON hd.id = ss.host_device_id
             LEFT JOIN users vu ON vu.id = ss.viewer_user_id
             WHERE ss.session_code = ? LIMIT 1'
        );
        $stmt->execute([$sessionCode]);
        $session = $stmt->fetch();

        if (!$session || $session['host_device_uid'] !== $deviceUid) {
            errorResponse('forbidden', 'Invalid host device or session.', 403);
        }

        // Check paired viewer entitlement
        $viewerEntitled = true;
        if ($session['viewer_user_id'] !== null && $session['viewer_role'] !== 'admin') {
            $sub = evaluateUserSubscription($pdo, (int) $session['viewer_user_id']);
            $viewerEntitled = (bool) $sub['is_entitled'];
            if (!$viewerEntitled && $session['status'] === 'active') {
                $pdo->prepare("UPDATE support_sessions SET status = 'expired', ended_at = UTC_TIMESTAMP(), end_reason = 'Controller subscription expired' WHERE id = ?")
                    ->execute([$session['id']]);
                $session['status'] = 'expired';
            }
        }

        $commands = [];
        if ($session['status'] === 'active' && $viewerEntitled) {
            $cStmt = $pdo->prepare(
                "SELECT id, command_type, payload_json, created_at
                 FROM screen_frames_and_commands
                 WHERE session_id = ? AND record_type = 'command' AND is_processed = 0
                 ORDER BY id ASC LIMIT 20"
            );
            $cStmt->execute([$session['id']]);
            $rows = $cStmt->fetchAll();

            if (!empty($rows)) {
                $ids = array_map(static fn(array $r): int => (int) $r['id'], $rows);
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $mark = $pdo->prepare("UPDATE screen_frames_and_commands SET is_processed = 1 WHERE id IN ({$placeholders})");
                $mark->execute($ids);

                foreach ($rows as $r) {
                    $commands[] = [
                        'id'           => (int) $r['id'],
                        'command_type' => $r['command_type'],
                        'payload'      => json_decode((string) ($r['payload_json'] ?: '{}'), true) ?: [],
                        'created_at'   => $r['created_at'],
                    ];
                }
            }
        }

        jsonResponse([
            'ok'                       => true,
            'session_status'           => $session['status'],
            'quality_mode'             => $session['quality_mode'],
            'assisted_control_enabled' => ((int) $session['assisted_control_enabled']) === 1,
            'viewer_entitled'          => $viewerEntitled,
            'commands'                 => $commands,
        ]);
    }

    // ========================================================================
    // 6. SUBSCRIPTION PLANS, PAYMENT METHODS & MANUAL PAYMENT SUBMISSION
    // ========================================================================
    case 'list_plans': {
        $includeInactive = (($_GET['all'] ?? '0') === '1') && (getAuthenticatedUser($pdo)['role'] ?? '') === 'admin';
        $sql = $includeInactive
            ? 'SELECT * FROM subscription_plans ORDER BY sort_order ASC, id ASC'
            : 'SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY sort_order ASC, id ASC';
        $plans = $pdo->query($sql)->fetchAll();
        jsonResponse(['ok' => true, 'plans' => $plans]);
    }

    case 'list_payment_methods': {
        $includeInactive = (($_GET['all'] ?? '0') === '1') && (getAuthenticatedUser($pdo)['role'] ?? '') === 'admin';
        $sql = $includeInactive
            ? 'SELECT * FROM payment_methods ORDER BY sort_order ASC, id ASC'
            : 'SELECT * FROM payment_methods WHERE is_active = 1 ORDER BY sort_order ASC, id ASC';
        $methods = $pdo->query($sql)->fetchAll();
        jsonResponse(['ok' => true, 'payment_methods' => $methods]);
    }

    case 'get_my_subscription': {
        $user = requireUser($pdo);
        jsonResponse([
            'ok'           => true,
            'subscription' => evaluateUserSubscription($pdo, (int) $user['id']),
        ]);
    }

    case 'submit_payment_request': {
        $user = requireUser($pdo);
        $planId = (int) ($body['plan_id'] ?? 0);
        $methodId = (int) ($body['payment_method_id'] ?? 0);
        $senderNumber = cleanString($body['sender_number'] ?? '', 120);
        $amount = (float) ($body['amount'] ?? 0);
        $trxId = strtoupper(cleanString($body['trx_id'] ?? '', 120));

        if ($planId <= 0 || $methodId <= 0 || $senderNumber === '' || $trxId === '' || $amount <= 0) {
            errorResponse('invalid_payment_submission', 'Plan, payment method, sender number, amount, and TrxID are required.', 422);
        }

        $pStmt = $pdo->prepare('SELECT id, currency FROM subscription_plans WHERE id = ? AND is_active = 1 LIMIT 1');
        $pStmt->execute([$planId]);
        $plan = $pStmt->fetch();
        if (!$plan) {
            errorResponse('plan_not_found', 'Selected subscription plan is not available.', 404);
        }

        $mStmt = $pdo->prepare('SELECT id FROM payment_methods WHERE id = ? AND is_active = 1 LIMIT 1');
        $mStmt->execute([$methodId]);
        if (!$mStmt->fetch()) {
            errorResponse('method_not_found', 'Selected payment method is not available.', 404);
        }

        try {
            $ins = $pdo->prepare(
                "INSERT INTO payment_requests (user_id, plan_id, payment_method_id, sender_number, amount, currency, trx_id, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')"
            );
            $ins->execute([$user['id'], $planId, $methodId, $senderNumber, $amount, $plan['currency'], $trxId]);
        } catch (PDOException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                errorResponse('duplicate_trx_id', 'This Transaction ID has already been submitted.', 409);
            }
            throw $e;
        }

        jsonResponse([
            'ok'                 => true,
            'payment_request_id' => (int) $pdo->lastInsertId(),
            'status'             => 'pending',
            'subscription'       => evaluateUserSubscription($pdo, (int) $user['id']),
        ], 201);
    }

    case 'list_my_payment_requests': {
        $user = requireUser($pdo);
        $stmt = $pdo->prepare(
            'SELECT pr.*, sp.title AS plan_title, sp.duration_days, pm.name AS method_name
             FROM payment_requests pr
             JOIN subscription_plans sp ON sp.id = pr.plan_id
             JOIN payment_methods pm ON pm.id = pr.payment_method_id
             WHERE pr.user_id = ?
             ORDER BY pr.created_at DESC LIMIT 50'
        );
        $stmt->execute([$user['id']]);
        jsonResponse(['ok' => true, 'requests' => $stmt->fetchAll()]);
    }

    // ========================================================================
    // 7. ADMIN CONSOLE FULL CRUD, VERIFICATION QUEUE & DYNAMIC SERVER CONFIG
    // ========================================================================
    case 'admin_stats': {
        requireAdmin($pdo);
        $totalUsers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'viewer'")->fetchColumn();
        $totalHosts = (int) $pdo->query("SELECT COUNT(*) FROM devices WHERE app_role = 'host'")->fetchColumn();
        $onlineHostsStmt = $pdo->prepare("SELECT COUNT(*) FROM devices WHERE app_role = 'host' AND TIMESTAMPDIFF(SECOND, last_seen, UTC_TIMESTAMP()) <= ?");
        $onlineHostsStmt->execute([ONLINE_THRESHOLD_SECONDS]);
        $onlineHosts = (int) $onlineHostsStmt->fetchColumn();

        $totalViewers = (int) $pdo->query("SELECT COUNT(*) FROM devices WHERE app_role = 'viewer'")->fetchColumn();
        $activeSessions = (int) $pdo->query("SELECT COUNT(*) FROM support_sessions WHERE status = 'active'")->fetchColumn();
        $pendingPayments = (int) $pdo->query("SELECT COUNT(*) FROM payment_requests WHERE status = 'pending'")->fetchColumn();
        $activePaidSubs = (int) $pdo->query("SELECT COUNT(*) FROM user_subscriptions WHERE status = 'active' AND expires_at > UTC_TIMESTAMP()")->fetchColumn();
        $activeTrials = (int) $pdo->query("SELECT COUNT(*) FROM user_subscriptions WHERE status = 'trial' AND expires_at > UTC_TIMESTAMP()")->fetchColumn();

        $recentSessions = $pdo->query(
            'SELECT ss.id, ss.session_code, ss.status, ss.quality_mode, ss.created_at, ss.accepted_at, ss.ended_at,
                    hd.device_name AS host_name, vu.email AS viewer_email
             FROM support_sessions ss
             JOIN devices hd ON hd.id = ss.host_device_id
             LEFT JOIN users vu ON vu.id = ss.viewer_user_id
             ORDER BY ss.id DESC LIMIT 15'
        )->fetchAll();

        jsonResponse([
            'ok'              => true,
            'server_time_utc' => gmdate('Y-m-d H:i:s'),
            'database_status' => 'healthy',
            'metrics'         => [
                'total_users'       => $totalUsers,
                'total_hosts'       => $totalHosts,
                'online_hosts'      => $onlineHosts,
                'total_viewers'     => $totalViewers,
                'active_sessions'   => $activeSessions,
                'pending_payments'  => $pendingPayments,
                'active_paid_subs'  => $activePaidSubs,
                'active_trials'     => $activeTrials,
            ],
            'recent_sessions' => $recentSessions,
        ]);
    }

    case 'admin_save_plan': {
        requireAdmin($pdo);
        $id = (int) ($body['id'] ?? 0);
        $title = cleanString($body['title'] ?? '', 120);
        $description = cleanString($body['description'] ?? '', 255);
        $price = (float) ($body['price_amount'] ?? 0);
        $currency = strtoupper(cleanString($body['currency'] ?? 'BDT', 16));
        $durationDays = max(1, (int) ($body['duration_days'] ?? 30));
        $isActive = isset($body['is_active']) ? ((bool) $body['is_active'] ? 1 : 0) : 1;
        $sortOrder = (int) ($body['sort_order'] ?? 0);

        if ($title === '' || $price < 0) {
            errorResponse('invalid_plan', 'Valid plan title and non-negative price are required.', 422);
        }

        if ($id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE subscription_plans
                 SET title = ?, description = ?, price_amount = ?, currency = ?, duration_days = ?, is_active = ?, sort_order = ?
                 WHERE id = ?'
            );
            $stmt->execute([$title, $description, $price, $currency, $durationDays, $isActive, $sortOrder, $id]);
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO subscription_plans (title, description, price_amount, currency, duration_days, is_active, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$title, $description, $price, $currency, $durationDays, $isActive, $sortOrder]);
            $id = (int) $pdo->lastInsertId();
        }
        jsonResponse(['ok' => true, 'plan_id' => $id]);
    }

    case 'admin_delete_plan': {
        requireAdmin($pdo);
        $id = (int) ($body['id'] ?? 0);
        if ($id <= 0) {
            errorResponse('invalid_plan_id', 'Valid plan id is required.', 422);
        }
        try {
            $pdo->prepare('DELETE FROM subscription_plans WHERE id = ?')->execute([$id]);
        } catch (PDOException $e) {
            // Plan referenced by payment_requests; deactivate cleanly instead
            $pdo->prepare('UPDATE subscription_plans SET is_active = 0 WHERE id = ?')->execute([$id]);
        }
        jsonResponse(['ok' => true]);
    }

    case 'admin_save_payment_method': {
        requireAdmin($pdo);
        $id = (int) ($body['id'] ?? 0);
        $name = cleanString($body['name'] ?? '', 80);
        $accountName = cleanString($body['account_name'] ?? '', 120);
        $accountNumber = cleanString($body['account_number'] ?? '', 160);
        $instructions = cleanString($body['instructions'] ?? '', 1000);
        $isActive = isset($body['is_active']) ? ((bool) $body['is_active'] ? 1 : 0) : 1;
        $sortOrder = (int) ($body['sort_order'] ?? 0);

        if ($name === '' || $accountNumber === '') {
            errorResponse('invalid_payment_method', 'Method name and account number/wallet are required.', 422);
        }

        if ($id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE payment_methods
                 SET name = ?, account_name = ?, account_number = ?, instructions = ?, is_active = ?, sort_order = ?
                 WHERE id = ?'
            );
            $stmt->execute([$name, $accountName, $accountNumber, $instructions, $isActive, $sortOrder, $id]);
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO payment_methods (name, account_name, account_number, instructions, is_active, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$name, $accountName, $accountNumber, $instructions, $isActive, $sortOrder]);
            $id = (int) $pdo->lastInsertId();
        }
        jsonResponse(['ok' => true, 'payment_method_id' => $id]);
    }

    case 'admin_delete_payment_method': {
        requireAdmin($pdo);
        $id = (int) ($body['id'] ?? 0);
        if ($id <= 0) {
            errorResponse('invalid_method_id', 'Valid payment method id is required.', 422);
        }
        try {
            $pdo->prepare('DELETE FROM payment_methods WHERE id = ?')->execute([$id]);
        } catch (PDOException $e) {
            $pdo->prepare('UPDATE payment_methods SET is_active = 0 WHERE id = ?')->execute([$id]);
        }
        jsonResponse(['ok' => true]);
    }

    case 'admin_list_payment_requests': {
        requireAdmin($pdo);
        $statusFilter = cleanString($_GET['status'] ?? '', 24);
        if (in_array($statusFilter, ['pending', 'approved', 'rejected'], true)) {
            $stmt = $pdo->prepare(
                'SELECT pr.*, u.email AS user_email, u.full_name AS user_name,
                        sp.title AS plan_title, sp.duration_days, pm.name AS method_name
                 FROM payment_requests pr
                 JOIN users u ON u.id = pr.user_id
                 JOIN subscription_plans sp ON sp.id = pr.plan_id
                 JOIN payment_methods pm ON pm.id = pr.payment_method_id
                 WHERE pr.status = ?
                 ORDER BY pr.created_at DESC LIMIT 100'
            );
            $stmt->execute([$statusFilter]);
        } else {
            $stmt = $pdo->query(
                'SELECT pr.*, u.email AS user_email, u.full_name AS user_name,
                        sp.title AS plan_title, sp.duration_days, pm.name AS method_name
                 FROM payment_requests pr
                 JOIN users u ON u.id = pr.user_id
                 JOIN subscription_plans sp ON sp.id = pr.plan_id
                 JOIN payment_methods pm ON pm.id = pr.payment_method_id
                 ORDER BY FIELD(pr.status, "pending", "approved", "rejected"), pr.created_at DESC LIMIT 100'
            );
        }
        jsonResponse(['ok' => true, 'requests' => $stmt->fetchAll()]);
    }

    case 'admin_review_payment_request': {
        $admin = requireAdmin($pdo);
        $requestId = (int) ($body['payment_request_id'] ?? 0);
        $decision = strtolower(cleanString($body['decision'] ?? '', 16)); // approve | reject
        $adminNote = cleanString($body['admin_note'] ?? '', 255);

        if ($requestId <= 0 || !in_array($decision, ['approve', 'reject'], true)) {
            errorResponse('invalid_review', 'payment_request_id and decision (approve/reject) are required.', 422);
        }

        $stmt = $pdo->prepare(
            'SELECT pr.*, sp.duration_days, sp.title AS plan_title
             FROM payment_requests pr
             JOIN subscription_plans sp ON sp.id = pr.plan_id
             WHERE pr.id = ? LIMIT 1'
        );
        $stmt->execute([$requestId]);
        $pr = $stmt->fetch();
        if (!$pr) {
            errorResponse('request_not_found', 'Payment request not found.', 404);
        }
        if ($pr['status'] !== 'pending') {
            errorResponse('already_reviewed', "Payment request is already {$pr['status']}.", 409);
        }

        $pdo->beginTransaction();
        try {
            if ($decision === 'approve') {
                $updPr = $pdo->prepare(
                    "UPDATE payment_requests SET status = 'approved', admin_note = ?, reviewed_by_admin_id = ?, reviewed_at = UTC_TIMESTAMP() WHERE id = ?"
                );
                $updPr->execute([$adminNote, $admin['id'], $requestId]);

                // Extend from max(now, current expires_at) by plan duration_days
                $curStmt = $pdo->prepare('SELECT id, expires_at FROM user_subscriptions WHERE user_id = ? LIMIT 1');
                $curStmt->execute([$pr['user_id']]);
                $cur = $curStmt->fetch();

                $baseTs = time();
                if ($cur) {
                    $curExp = strtotime((string) $cur['expires_at'] . ' UTC') ?: 0;
                    if ($curExp > $baseTs) {
                        $baseTs = $curExp;
                    }
                }
                $newExpiry = gmdate('Y-m-d H:i:s', $baseTs + ((int) $pr['duration_days'] * 86400));

                if ($cur) {
                    $updSub = $pdo->prepare(
                        "UPDATE user_subscriptions
                         SET plan_id = ?, status = 'active', expires_at = ?, updated_by_admin_id = ?, notes = ?
                         WHERE id = ?"
                    );
                    $updSub->execute([$pr['plan_id'], $newExpiry, $admin['id'], "Approved TrxID {$pr['trx_id']}", $cur['id']]);
                } else {
                    $insSub = $pdo->prepare(
                        "INSERT INTO user_subscriptions (user_id, plan_id, status, starts_at, expires_at, updated_by_admin_id, notes)
                         VALUES (?, ?, 'active', UTC_TIMESTAMP(), ?, ?, ?)"
                    );
                    $insSub->execute([$pr['user_id'], $pr['plan_id'], $newExpiry, $admin['id'], "Approved TrxID {$pr['trx_id']}"]);
                }
            } else {
                $updPr = $pdo->prepare(
                    "UPDATE payment_requests SET status = 'rejected', admin_note = ?, reviewed_by_admin_id = ?, reviewed_at = UTC_TIMESTAMP() WHERE id = ?"
                );
                $updPr->execute([$adminNote !== '' ? $adminNote : 'Rejected by administrator', $admin['id'], $requestId]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            errorResponse('review_failed', 'Failed to review payment request.', 500);
        }

        jsonResponse([
            'ok'           => true,
            'decision'     => $decision,
            'subscription' => evaluateUserSubscription($pdo, (int) $pr['user_id']),
        ]);
    }

    case 'admin_list_users': {
        requireAdmin($pdo);
        $rows = $pdo->query(
            "SELECT u.id, u.email, u.full_name, u.phone, u.role, u.is_active, u.created_at,
                    us.status AS sub_status, us.expires_at, sp.title AS plan_title
             FROM users u
             LEFT JOIN user_subscriptions us ON us.user_id = u.id
             LEFT JOIN subscription_plans sp ON sp.id = us.plan_id
             WHERE u.role = 'viewer'
             ORDER BY u.id DESC LIMIT 100"
        )->fetchAll();
        jsonResponse(['ok' => true, 'users' => $rows]);
    }

    case 'admin_manage_subscription': {
        $admin = requireAdmin($pdo);
        $userId = (int) ($body['user_id'] ?? 0);
        $operation = strtolower(cleanString($body['operation'] ?? '', 24)); // activate | extend | pause | revoke
        $days = max(1, (int) ($body['days'] ?? 30));
        $notes = cleanString($body['notes'] ?? '', 255);

        if ($userId <= 0 || !in_array($operation, ['activate', 'extend', 'pause', 'revoke'], true)) {
            errorResponse('invalid_operation', 'user_id and operation (activate/extend/pause/revoke) are required.', 422);
        }

        $curStmt = $pdo->prepare('SELECT id, expires_at FROM user_subscriptions WHERE user_id = ? LIMIT 1');
        $curStmt->execute([$userId]);
        $cur = $curStmt->fetch();

        if ($operation === 'activate' || $operation === 'extend') {
            $baseTs = time();
            if ($operation === 'extend' && $cur) {
                $curExp = strtotime((string) $cur['expires_at'] . ' UTC') ?: 0;
                if ($curExp > $baseTs) {
                    $baseTs = $curExp;
                }
            }
            $newExpiry = gmdate('Y-m-d H:i:s', $baseTs + ($days * 86400));
            if ($cur) {
                $pdo->prepare("UPDATE user_subscriptions SET status = 'active', expires_at = ?, updated_by_admin_id = ?, notes = ? WHERE id = ?")
                    ->execute([$newExpiry, $admin['id'], $notes, $cur['id']]);
            } else {
                $pdo->prepare("INSERT INTO user_subscriptions (user_id, status, starts_at, expires_at, updated_by_admin_id, notes) VALUES (?, 'active', UTC_TIMESTAMP(), ?, ?, ?)")
                    ->execute([$userId, $newExpiry, $admin['id'], $notes]);
            }
        } else {
            $newStatus = $operation === 'pause' ? 'paused' : 'revoked';
            if ($cur) {
                $pdo->prepare('UPDATE user_subscriptions SET status = ?, updated_by_admin_id = ?, notes = ? WHERE id = ?')
                    ->execute([$newStatus, $admin['id'], $notes, $cur['id']]);
            } else {
                $pdo->prepare('INSERT INTO user_subscriptions (user_id, status, starts_at, expires_at, updated_by_admin_id, notes) VALUES (?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP(), ?, ?)')
                    ->execute([$userId, $newStatus, $admin['id'], $notes]);
            }
        }

        jsonResponse([
            'ok'           => true,
            'subscription' => evaluateUserSubscription($pdo, $userId),
        ]);
    }

    case 'admin_get_config': {
        requireAdmin($pdo);
        jsonResponse(['ok' => true, 'config' => getConfigMap($pdo)]);
    }

    case 'admin_update_config': {
        requireAdmin($pdo);
        $allowedKeys = [
            'base_api_url',
            'frame_interval_ms',
            'command_poll_interval_ms',
            'default_trial_days',
            'trial_enabled',
            'api_secret_key',
            'app_update_notice',
        ];
        $updates = is_array($body['config'] ?? null) ? $body['config'] : $body;
        $stmt = $pdo->prepare(
            'INSERT INTO app_server_config (config_key, config_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)'
        );
        foreach ($allowedKeys as $key) {
            if (array_key_exists($key, $updates)) {
                $val = cleanString((string) $updates[$key], 500);
                $stmt->execute([$key, $val]);
            }
        }
        jsonResponse(['ok' => true, 'config' => getConfigMap($pdo)]);
    }

    default:
        errorResponse('unknown_action', "Unknown API action: {$action}", 404);
}
