package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.ScreenShare
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.HostViewModel
import com.example.ui.components.ActiveSupportFloatingBadge
import com.example.ui.components.IncomingConnectionDialog
import com.example.ui.screens.HostDashboardScreen
import com.example.ui.screens.OnboardingConsentScreen
import com.example.ui.screens.ServerConfigScreen
import com.example.ui.theme.RemoteSupportHostTheme

private enum class HostDestination(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    SESSION(R.string.nav_session, Icons.Rounded.ScreenShare, Icons.Outlined.ScreenShare, "nav_session"),
    SERVER(R.string.nav_server, Icons.Rounded.Dns, Icons.Outlined.Dns, "nav_server"),
    CONSENT(R.string.nav_consent, Icons.Rounded.Shield, Icons.Outlined.Shield, "nav_consent")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            RemoteSupportHostTheme {
                RemoteSupportHostApp()
            }
        }
    }
}

@Composable
private fun RemoteSupportHostApp(
    viewModel: HostViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbarHostState = remember { SnackbarHostState() }

    var currentDestination by rememberSaveable { mutableStateOf(HostDestination.SESSION) }

    // Runtime notification permission check (API 33+)
    fun isNotificationPermissionGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshPermissionStates(notificationsGranted = granted)
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            viewModel.onAcceptConfirmedWithProjection(result.resultCode, data)
        } else {
            viewModel.onMediaProjectionCancelled()
        }
    }

    fun launchMediaProjectionConsent() {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    fun openAccessibilitySettings() {
        runCatching {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.refreshPermissionStates(true)
        }
    }

    // Refresh Accessibility & Notification states whenever user returns from Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissionStates(isNotificationPermissionGranted())
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    // First-run Transparent Setup & Consent screen
    if (uiState.settingsLoaded && !uiState.settings.consentAccepted) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { innerPadding ->
            OnboardingConsentScreen(
                isStandaloneOnboarding = true,
                accessibilityEnabled = uiState.accessibilityEnabled,
                notificationsGranted = uiState.notificationsGranted,
                onOpenAccessibilitySettings = ::openAccessibilitySettings,
                onRequestNotificationPermission = ::requestNotifications,
                onAcceptConsent = {
                    if (!isNotificationPermissionGranted() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        requestNotifications()
                    }
                    viewModel.completeOnboardingConsent()
                },
                modifier = Modifier.padding(innerPadding)
            )
        }
        return
    }

    // Back handling for secondary tabs returns cleanly to Session dashboard
    if (currentDestination != HostDestination.SESSION) {
        BackHandler {
            currentDestination = HostDestination.SESSION
        }
    }

    // Incoming Viewer Approval Modal (Explicit Host Accept / Decline)
    uiState.pendingRequest?.let { pending ->
        IncomingConnectionDialog(
            request = pending,
            assistedControlAllowed = uiState.settings.assistedControlAllowed,
            accessibilityEnabled = uiState.accessibilityEnabled,
            onToggleAssistedControl = { viewModel.setAssistedControlPreference(it) },
            onAccept = { launchMediaProjectionConsent() },
            onDecline = { viewModel.declineIncomingRequest() }
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp
                    ) {
                        HostDestination.entries.forEach { dest ->
                            val selected = currentDestination == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentDestination = dest },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        HostDestination.entries.forEach { dest ->
                            val selected = currentDestination == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentDestination = dest },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                ) {
                    // Always-accessible floating stop badge when remote support is live
                    ActiveSupportFloatingBadge(
                        visible = uiState.liveSharing.isSharingActive,
                        viewerName = uiState.liveSharing.viewerName,
                        pausedForNetwork = uiState.liveSharing.pausedForNetwork,
                        onStopClicked = { viewModel.stopActiveSharing("Stopped from floating active badge") }
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                    ) {
                        when (currentDestination) {
                            HostDestination.SESSION -> HostDashboardScreen(
                                uiState = uiState,
                                onCreateNewSession = { viewModel.createNewSupportSession() },
                                onStopActiveSession = { viewModel.stopActiveSharing("Stopped from Host Dashboard") },
                                onToggleAssistedControl = { viewModel.setAssistedControlPreference(it) },
                                onOpenServerSettings = { currentDestination = HostDestination.SERVER },
                                onOpenAccessibilitySettings = ::openAccessibilitySettings,
                                onRequestNotificationPermission = ::requestNotifications,
                                onCopiedCredentials = {
                                    viewModel.showMessage("Session ID & 6-digit PIN copied")
                                }
                            )

                            HostDestination.SERVER -> ServerConfigScreen(
                                uiState = uiState,
                                onSaveAndTest = { url, key, name ->
                                    viewModel.saveAndTestServerConfig(url, key, name)
                                }
                            )

                            HostDestination.CONSENT -> OnboardingConsentScreen(
                                isStandaloneOnboarding = false,
                                accessibilityEnabled = uiState.accessibilityEnabled,
                                notificationsGranted = uiState.notificationsGranted,
                                onOpenAccessibilitySettings = ::openAccessibilitySettings,
                                onRequestNotificationPermission = ::requestNotifications,
                                onAcceptConsent = {}
                            )
                        }
                    }
                }
            }
        }
    }
}
