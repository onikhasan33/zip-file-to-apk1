package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.data.ApiResult
import com.example.data.NetworkMonitor
import com.example.data.RemoteCommandDto
import com.example.data.SupportApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Foreground Service managing MediaProjection screen capture, JPEG frame upload
 * to the PHP + MySQL backend, and polling/dispatching of assisted gesture commands.
 *
 * Always displays an unmistakable persistent notification with a one-tap "Stop Sharing" button.
 */
class ScreenShareForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val apiClient = SupportApiClient()
    private lateinit var networkMonitor: NetworkMonitor

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var frameUploadJob: Job? = null
    private var commandPollJob: Job? = null

    private val isStopping = AtomicBoolean(false)
    private val frameSequence = AtomicLong(0L)
    private val forceRefreshFlag = AtomicBoolean(false)

    @Volatile
    private var activeServerUrl: String = ""
    @Volatile
    private var activeApiKey: String = ""
    @Volatile
    private var activeSessionCode: String = ""
    @Volatile
    private var activeDeviceUid: String = ""
    @Volatile
    private var frameIntervalMs: Long = 650L
    @Volatile
    private var commandPollIntervalMs: Long = 350L
    @Volatile
    private var currentQualityMode: String = "balanced"

    private var captureWidth: Int = 540
    private var captureHeight: Int = 960

    override fun onCreate() {
        super.onCreate()
        networkMonitor = NetworkMonitor(applicationContext).apply { start() }
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SHARING -> {
                val reason = intent.getStringExtra(EXTRA_STOP_REASON) ?: "Stopped by Host user"
                stopSharingAndCleanup(reason = reason, notifyServer = true)
                return START_NOT_STICKY
            }

            ACTION_START_SHARING -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE)
                val projectionData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
                }

                if (resultCode == Int.MIN_VALUE || projectionData == null) {
                    stopSharingAndCleanup("Screen capture permission missing", notifyServer = false)
                    return START_NOT_STICKY
                }

                activeServerUrl = intent.getStringExtra(EXTRA_SERVER_URL).orEmpty()
                activeApiKey = intent.getStringExtra(EXTRA_API_KEY).orEmpty()
                activeSessionCode = intent.getStringExtra(EXTRA_SESSION_CODE).orEmpty()
                activeDeviceUid = intent.getStringExtra(EXTRA_DEVICE_UID).orEmpty()
                val viewerName = intent.getStringExtra(EXTRA_VIEWER_NAME).orEmpty().ifBlank { "Support Agent" }
                val subLabel = intent.getStringExtra(EXTRA_VIEWER_SUB_LABEL).orEmpty().ifBlank { "Verified" }
                currentQualityMode = intent.getStringExtra(EXTRA_QUALITY_MODE).orEmpty().ifBlank { "balanced" }
                val assistedAllowed = intent.getBooleanExtra(EXTRA_ASSISTED_ALLOWED, true)
                frameIntervalMs = intent.getIntExtra(EXTRA_FRAME_INTERVAL_MS, 650).coerceIn(250, 3000).toLong()
                commandPollIntervalMs = intent.getIntExtra(EXTRA_COMMAND_POLL_MS, 350).coerceIn(200, 2000).toLong()

                isStopping.set(false)

                val notification = buildActiveNotification(viewerName, activeSessionCode)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ServiceCompat.startForeground(
                        this,
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }

                SupportSessionRuntime.onSessionStarted(
                    sessionCode = activeSessionCode,
                    viewerName = viewerName,
                    viewerSubscriptionLabel = subLabel,
                    qualityMode = currentQualityMode,
                    assistedAllowed = assistedAllowed
                )

                startMediaProjectionPipeline(resultCode, projectionData)
            }
        }
        return START_NOT_STICKY
    }

    private fun startMediaProjectionPipeline(resultCode: Int, projectionData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = try {
            projectionManager.getMediaProjection(resultCode, projectionData)
        } catch (_: Exception) {
            null
        }

        if (projection == null) {
            stopSharingAndCleanup("Unable to initialize MediaProjection", notifyServer = true)
            return
        }

        mediaProjection = projection
        captureThread = HandlerThread("HostScreenCaptureThread").apply { start() }
        captureHandler = Handler(captureThread!!.looper)

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSharingAndCleanup("Screen sharing stopped by system", notifyServer = true)
            }
        }, captureHandler)

        setupVirtualDisplay(projection, currentQualityMode)
        startFrameUploadLoop()
        startCommandPollingLoop()
    }

    private fun setupVirtualDisplay(projection: MediaProjection, quality: String) {
        virtualDisplay?.release()
        imageReader?.close()

        val metrics = resources.displayMetrics
        val maxDim = when (quality) {
            "high" -> 720
            "low" -> 360
            else -> 540
        }
        val aspect = metrics.widthPixels.toFloat() / metrics.heightPixels.coerceAtLeast(1).toFloat()
        if (metrics.widthPixels >= metrics.heightPixels) {
            captureWidth = maxDim
            captureHeight = (maxDim / aspect.coerceAtLeast(0.4f)).toInt().coerceAtLeast(240)
        } else {
            captureHeight = maxDim
            captureWidth = (maxDim * aspect.coerceAtMost(2.5f)).toInt().coerceAtLeast(240)
        }
        // Keep even dimensions for surface encoders/readers
        captureWidth = captureWidth and 1.inv()
        captureHeight = captureHeight and 1.inv()

        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection.createVirtualDisplay(
            "RemoteSupportHostDisplay",
            captureWidth,
            captureHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )
    }

    private fun startFrameUploadLoop() {
        frameUploadJob?.cancel()
        frameUploadJob = serviceScope.launch {
            while (isActive && !isStopping.get()) {
                if (!networkMonitor.isOnline) {
                    SupportSessionRuntime.setPausedForNetwork(true)
                    delay(1200L)
                    continue
                }
                SupportSessionRuntime.setPausedForNetwork(false)

                val jpegBase64 = captureLatestFrameBase64()
                if (jpegBase64 != null) {
                    val seq = frameSequence.incrementAndGet()
                    when (
                        val result = apiClient.uploadFrame(
                            baseUrl = activeServerUrl,
                            apiKey = activeApiKey,
                            sessionCode = activeSessionCode,
                            deviceUid = activeDeviceUid,
                            frameBase64 = jpegBase64,
                            width = captureWidth,
                            height = captureHeight,
                            frameSeq = seq
                        )
                    ) {
                        is ApiResult.Success -> {
                            SupportSessionRuntime.recordFrameSent()
                            val newQuality = result.data.qualityMode
                            if (newQuality.isNotBlank() && newQuality != currentQualityMode) {
                                currentQualityMode = newQuality
                                SupportSessionRuntime.setQualityMode(newQuality)
                                mediaProjection?.let { proj ->
                                    captureHandler?.post { setupVirtualDisplay(proj, newQuality) }
                                }
                            }
                        }

                        is ApiResult.Failure -> {
                            if (result.errorCode == "subscription_expired" ||
                                result.errorCode == "session_inactive" ||
                                result.httpCode == 403
                            ) {
                                stopSharingAndCleanup(result.message, notifyServer = false)
                                break
                            }
                        }
                    }
                }

                val waitMs = if (forceRefreshFlag.getAndSet(false)) 150L else frameIntervalMs
                delay(waitMs)
            }
        }
    }

    private fun captureLatestFrameBase64(): String? {
        val reader = imageReader ?: return null
        val image = try {
            reader.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return null

        var fullBitmap: Bitmap? = null
        var croppedBitmap: Bitmap? = null
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmapWidth = image.width + rowPadding / pixelStride

            fullBitmap = Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888)
            fullBitmap.copyPixelsFromBuffer(buffer)
            croppedBitmap = if (bitmapWidth != image.width) {
                Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
            } else {
                fullBitmap
            }

            val jpegQuality = when (currentQualityMode) {
                "high" -> 72
                "low" -> 40
                else -> 55
            }
            val output = ByteArrayOutputStream()
            croppedBitmap.compress(Bitmap.CompressFormat.JPEG, jpegQuality, output)
            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        } finally {
            image.close()
            if (croppedBitmap != null && croppedBitmap !== fullBitmap) {
                croppedBitmap.recycle()
            }
            fullBitmap?.recycle()
        }
    }

    private fun startCommandPollingLoop() {
        commandPollJob?.cancel()
        commandPollJob = serviceScope.launch {
            while (isActive && !isStopping.get()) {
                if (!networkMonitor.isOnline) {
                    delay(1200L)
                    continue
                }
                when (
                    val res = apiClient.pollCommands(
                        baseUrl = activeServerUrl,
                        apiKey = activeApiKey,
                        sessionCode = activeSessionCode,
                        deviceUid = activeDeviceUid
                    )
                ) {
                    is ApiResult.Success -> {
                        val data = res.data
                        if (!data.viewerEntitled) {
                            stopSharingAndCleanup("Controller trial or subscription expired", notifyServer = false)
                            break
                        }
                        if (data.sessionStatus != "active") {
                            stopSharingAndCleanup("Session ended (${data.sessionStatus})", notifyServer = false)
                            break
                        }
                        for (cmd in data.commands) {
                            handleRemoteCommand(cmd)
                        }
                    }

                    is ApiResult.Failure -> {
                        if (res.httpCode == 403 || res.errorCode == "subscription_expired") {
                            stopSharingAndCleanup(res.message, notifyServer = false)
                            break
                        }
                    }
                }
                delay(commandPollIntervalMs)
            }
        }
    }

    private fun handleRemoteCommand(cmd: RemoteCommandDto) {
        when (cmd.commandType) {
            "disconnect" -> {
                stopSharingAndCleanup("Disconnected by Support Agent", notifyServer = false)
            }

            "refresh" -> {
                forceRefreshFlag.set(true)
                SupportSessionRuntime.recordCommandExecuted("Refresh Frame")
            }

            "tap" -> {
                val p = cmd.payload ?: return
                val executed = SupportAccessibilityService.instance
                    ?.performTapNormalized(p.x ?: 0.5f, p.y ?: 0.5f) == true
                if (executed) {
                    SupportSessionRuntime.recordCommandExecuted("Assisted Tap")
                }
            }

            "swipe" -> {
                val p = cmd.payload ?: return
                val executed = SupportAccessibilityService.instance
                    ?.performSwipeNormalized(
                        normX1 = p.x1 ?: 0.5f,
                        normY1 = p.y1 ?: 0.5f,
                        normX2 = p.x2 ?: 0.5f,
                        normY2 = p.y2 ?: 0.5f,
                        durationMs = p.durationMs ?: 280L
                    ) == true
                if (executed) {
                    SupportSessionRuntime.recordCommandExecuted("Assisted Swipe")
                }
            }

            "home", "back", "recents" -> {
                val executed = SupportAccessibilityService.instance
                    ?.performNavigationAction(cmd.commandType) == true
                if (executed) {
                    SupportSessionRuntime.recordCommandExecuted("Nav: ${cmd.commandType.replaceFirstChar { it.uppercase() }}")
                }
            }
        }
    }

    private fun stopSharingAndCleanup(reason: String, notifyServer: Boolean) {
        if (!isStopping.compareAndSet(false, true)) return

        frameUploadJob?.cancel()
        commandPollJob?.cancel()

        val codeToEnd = activeSessionCode
        val urlToEnd = activeServerUrl
        val keyToEnd = activeApiKey

        if (notifyServer && codeToEnd.isNotBlank() && urlToEnd.isNotBlank()) {
            serviceScope.launch {
                runCatching {
                    apiClient.endSession(urlToEnd, keyToEnd, codeToEnd, reason)
                }
            }
        }

        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }
        runCatching { mediaProjection?.stop() }
        runCatching { captureThread?.quitSafely() }

        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        captureThread = null
        captureHandler = null

        SupportSessionRuntime.onSessionStopped(reason)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        networkMonitor.stop()
        if (!isStopping.get()) {
            stopSharingAndCleanup("Service closed", notifyServer = false)
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildActiveNotification(viewerName: String, sessionCode: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = createStopIntent(this, "Stopped from notification bar")
        val stopPendingIntent = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.notification_active_title))
            .setContentText(getString(R.string.notification_active_body, viewerName, sessionCode))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.action_stop_sharing),
                stopPendingIntent
            )
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "remote_support_active_channel"
        private const val NOTIFICATION_ID = 4201

        const val ACTION_START_SHARING = "com.example.action.START_SHARING"
        const val ACTION_STOP_SHARING = "com.example.action.STOP_SHARING"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_PROJECTION_DATA = "extra_projection_data"
        const val EXTRA_SERVER_URL = "extra_server_url"
        const val EXTRA_API_KEY = "extra_api_key"
        const val EXTRA_SESSION_CODE = "extra_session_code"
        const val EXTRA_DEVICE_UID = "extra_device_uid"
        const val EXTRA_VIEWER_NAME = "extra_viewer_name"
        const val EXTRA_VIEWER_SUB_LABEL = "extra_viewer_sub_label"
        const val EXTRA_QUALITY_MODE = "extra_quality_mode"
        const val EXTRA_ASSISTED_ALLOWED = "extra_assisted_allowed"
        const val EXTRA_FRAME_INTERVAL_MS = "extra_frame_interval_ms"
        const val EXTRA_COMMAND_POLL_MS = "extra_command_poll_ms"
        const val EXTRA_STOP_REASON = "extra_stop_reason"

        fun createStopIntent(context: Context, reason: String): Intent =
            Intent(context, ScreenShareForegroundService::class.java).apply {
                action = ACTION_STOP_SHARING
                putExtra(EXTRA_STOP_REASON, reason)
            }
    }
}
