package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LiveSharingState(
    val isSharingActive: Boolean = false,
    val sessionCode: String = "",
    val viewerName: String = "",
    val viewerSubscriptionLabel: String = "",
    val qualityMode: String = "balanced",
    val assistedGesturesAllowed: Boolean = true,
    val isAccessibilityServiceConnected: Boolean = false,
    val framesSent: Long = 0L,
    val commandsExecuted: Long = 0L,
    val lastCommandLabel: String = "",
    val pausedForNetwork: Boolean = false,
    val lastStopReason: String? = null
)

/**
 * Shared thread-safe runtime state bridging MainActivity / HostViewModel,
 * ScreenShareForegroundService, and SupportAccessibilityService.
 */
object SupportSessionRuntime {

    private val _state = MutableStateFlow(LiveSharingState())
    val state: StateFlow<LiveSharingState> = _state.asStateFlow()

    fun onSessionStarted(
        sessionCode: String,
        viewerName: String,
        viewerSubscriptionLabel: String,
        qualityMode: String,
        assistedAllowed: Boolean
    ) {
        _state.update {
            it.copy(
                isSharingActive = true,
                sessionCode = sessionCode,
                viewerName = viewerName,
                viewerSubscriptionLabel = viewerSubscriptionLabel,
                qualityMode = qualityMode,
                assistedGesturesAllowed = assistedAllowed,
                framesSent = 0L,
                commandsExecuted = 0L,
                lastCommandLabel = "",
                pausedForNetwork = false,
                lastStopReason = null
            )
        }
    }

    fun onSessionStopped(reason: String) {
        _state.update {
            it.copy(
                isSharingActive = false,
                pausedForNetwork = false,
                lastStopReason = reason
            )
        }
    }

    fun setAssistedGesturesAllowed(allowed: Boolean) {
        _state.update { it.copy(assistedGesturesAllowed = allowed) }
    }

    fun setQualityMode(mode: String) {
        _state.update { it.copy(qualityMode = mode) }
    }

    fun setPausedForNetwork(paused: Boolean) {
        _state.update { it.copy(pausedForNetwork = paused) }
    }

    fun recordFrameSent() {
        _state.update { it.copy(framesSent = it.framesSent + 1L) }
    }

    fun recordCommandExecuted(label: String) {
        _state.update {
            it.copy(
                commandsExecuted = it.commandsExecuted + 1L,
                lastCommandLabel = label
            )
        }
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _state.update { it.copy(isAccessibilityServiceConnected = connected) }
    }

    /**
     * Strict safety gate checked before every remote gesture execution.
     */
    fun canExecuteAssistedGesture(): Boolean {
        val current = _state.value
        return current.isSharingActive && current.assistedGesturesAllowed && !current.pausedForNetwork
    }
}
