package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Transparent Assisted-Gesture AccessibilityService.
 *
 * Strictly executes tap, swipe, and navigation commands ONLY while an explicitly
 * accepted Remote Support session is active and the user has enabled Assisted Control.
 * Never reads screen content or captures input outside consented sessions.
 */
class SupportAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        SupportSessionRuntime.setAccessibilityConnected(true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally no-op: we do not inspect or log window contents or user typing.
    }

    override fun onInterrupt() {
        // Safe no-op
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        SupportSessionRuntime.setAccessibilityConnected(false)
        super.onDestroy()
    }

    fun performTapNormalized(normX: Float, normY: Float): Boolean {
        if (!SupportSessionRuntime.canExecuteAssistedGesture()) return false
        val metrics = resources.displayMetrics
        val px = (normX.coerceIn(0f, 1f) * metrics.widthPixels).coerceIn(1f, (metrics.widthPixels - 1).toFloat())
        val py = (normY.coerceIn(0f, 1f) * metrics.heightPixels).coerceIn(1f, (metrics.heightPixels - 1).toFloat())

        val path = Path().apply { moveTo(px, py) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun performSwipeNormalized(
        normX1: Float,
        normY1: Float,
        normX2: Float,
        normY2: Float,
        durationMs: Long
    ): Boolean {
        if (!SupportSessionRuntime.canExecuteAssistedGesture()) return false
        val metrics = resources.displayMetrics
        val x1 = (normX1.coerceIn(0f, 1f) * metrics.widthPixels).coerceIn(1f, (metrics.widthPixels - 1).toFloat())
        val y1 = (normY1.coerceIn(0f, 1f) * metrics.heightPixels).coerceIn(1f, (metrics.heightPixels - 1).toFloat())
        val x2 = (normX2.coerceIn(0f, 1f) * metrics.widthPixels).coerceIn(1f, (metrics.widthPixels - 1).toFloat())
        val y2 = (normY2.coerceIn(0f, 1f) * metrics.heightPixels).coerceIn(1f, (metrics.heightPixels - 1).toFloat())

        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val clampedDuration = durationMs.coerceIn(80L, 1400L)
        val stroke = GestureDescription.StrokeDescription(path, 0L, clampedDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun performNavigationAction(commandType: String): Boolean {
        if (!SupportSessionRuntime.canExecuteAssistedGesture()) return false
        return when (commandType) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            else -> false
        }
    }

    companion object {
        @Volatile
        var instance: SupportAccessibilityService? = null
            private set

        fun isEnabledInSystemSettings(context: Context): Boolean {
            if (instance != null) return true
            return try {
                val expected = ComponentName(context, SupportAccessibilityService::class.java).flattenToString()
                val enabledServices = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ).orEmpty()
                enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
            } catch (_: Exception) {
                false
            }
        }
    }
}
