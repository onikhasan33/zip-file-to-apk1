package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.HostUiState
import com.example.ui.ServerConnectionStatus
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalStatusPalette

@Composable
fun ServerConfigScreen(
    uiState: HostUiState,
    onSaveAndTest: (serverUrl: String, apiKey: String, deviceName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalStatusPalette.current

    var urlInput by remember { mutableStateOf(uiState.settings.serverUrl) }
    var apiKeyInput by remember { mutableStateOf(uiState.settings.apiSecretKey) }
    var deviceNameInput by remember { mutableStateOf(uiState.settings.deviceName) }

    LaunchedEffect(uiState.settingsLoaded) {
        if (uiState.settingsLoaded) {
            urlInput = uiState.settings.serverUrl
            apiKeyInput = uiState.settings.apiSecretKey
            deviceNameInput = uiState.settings.deviceName
        }
    }

    val isChecking = uiState.serverStatus is ServerConnectionStatus.Checking

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.server_config_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Connect directly to your self-hosted PHP + MySQL api.php endpoint. Zero Firebase services are used.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Form Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("PHP API Endpoint URL") },
                        placeholder = { Text("https://your-domain.com/backend/api.php") },
                        leadingIcon = { Icon(Icons.Rounded.Dns, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("server_url_input")
                    )

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text("API Secret Key (Optional X-API-Key)") },
                        placeholder = { Text("Leave blank unless set in Admin Console") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input")
                    )

                    OutlinedTextField(
                        value = deviceNameInput,
                        onValueChange = { deviceNameInput = it },
                        label = { Text("Host Device Display Name") },
                        leadingIcon = { Icon(Icons.Rounded.Devices, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("device_name_input")
                    )

                    Button(
                        onClick = { onSaveAndTest(urlInput, apiKeyInput, deviceNameInput) },
                        enabled = !isChecking && urlInput.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("save_test_server_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (isChecking) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Testing PHP + MySQL Server...")
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.CloudSync,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.btn_test_sync),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // Diagnostics & Synced Server Config Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Server Diagnostics",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        when (uiState.serverStatus) {
                            is ServerConnectionStatus.Connected -> StatusPillBadge(
                                label = "Connected",
                                containerColor = palette.activeContainer,
                                contentColor = palette.onActiveContainer,
                                icon = Icons.Rounded.CheckCircle
                            )

                            is ServerConnectionStatus.Error -> StatusPillBadge(
                                label = "Error",
                                containerColor = palette.stopContainer,
                                contentColor = palette.onStopContainer,
                                icon = Icons.Rounded.ErrorOutline
                            )

                            is ServerConnectionStatus.Checking -> StatusPillBadge(
                                label = "Checking",
                                containerColor = palette.pendingContainer,
                                contentColor = palette.onPendingContainer
                            )

                            ServerConnectionStatus.Unconfigured -> StatusPillBadge(
                                label = "Not Tested",
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (uiState.serverStatus is ServerConnectionStatus.Error) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = palette.stopContainer
                        ) {
                            Text(
                                text = uiState.serverStatus.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.onStopContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            )
                        }
                    }

                    DiagnosticRow(label = "Device UID", value = uiState.settings.deviceUid.ifBlank { "Initializing..." })
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    DiagnosticRow(
                        label = "Synced Frame Interval",
                        value = "${uiState.settings.frameIntervalMs} ms"
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    DiagnosticRow(
                        label = "Command Poll Interval",
                        value = "${uiState.settings.commandPollIntervalMs} ms"
                    )
                    if (uiState.serverStatus is ServerConnectionStatus.Connected) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        DiagnosticRow(
                            label = "MySQL Database",
                            value = if (uiState.serverStatus.databaseConnected) "Healthy" else "Unavailable"
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        DiagnosticRow(
                            label = "Round-Trip Latency",
                            value = "${uiState.serverStatus.latencyMs} ms"
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        DiagnosticRow(
                            label = "Viewer Free Trial",
                            value = "${uiState.serverStatus.defaultTrialDays} Days (Server-Enforced)"
                        )
                    }
                }
            }

            // Architecture Note
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Speed,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Tip: Upload backend/schema.sql to MySQL and host backend/config.php + backend/api.php on any PHP 8.1+ server (cPanel, VPS, or local XAMPP). Emulator loopback uses http://10.0.2.2/backend/api.php.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
