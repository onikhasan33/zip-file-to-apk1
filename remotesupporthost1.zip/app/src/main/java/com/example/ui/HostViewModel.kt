package com.example.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ApiResult
import com.example.data.HostPreferencesStore
import com.example.data.HostSettings
import com.example.data.NetworkMonitor
import com.example.data.NetworkType
import com.example.data.SupportApiClient
import com.example.service.LiveSharingState
import com.example.service.ScreenShareForegroundService
import com.example.service.SupportAccessibilityService
import com.example.service.SupportSessionRuntime
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ServerConnectionStatus {
    data object Unconfigured : ServerConnectionStatus()
    data object Checking : ServerConnectionStatus()
    data class Connected(
        val latencyMs: Long,
        val databaseConnected: Boolean,
        val serverTimeUtc: String,
        val defaultTrialDays: Int
    ) : ServerConnectionStatus()

    data class Error(val message: String) : ServerConnectionStatus()
}

data class PendingViewerRequest(
    val sessionCode: String,
    val viewerName: String,
    val viewerEmail: String,
    val subscriptionLabel: String,
    val subscriptionEntitled: Boolean
)

data class ActivityLogEntry(
    val id: Long,
    val timestamp: String,
    val title: String,
    val isWarning: Boolean = false
)

data class HostUiState(
    val settingsLoaded: Boolean = false,
    val settings: HostSettings = HostSettings(),
    val networkType: NetworkType = NetworkType.OFFLINE,
    val serverStatus: ServerConnectionStatus = ServerConnectionStatus.Unconfigured,
    val isRegisteredWithServer: Boolean = false,
    val isCreatingSession: Boolean = false,
    val sessionCode: String = "",
    val pinCode: String = "",
    val sessionStatusLabel: String = "idle",
    val pendingRequest: PendingViewerRequest? = null,
    val liveSharing: LiveSharingState = LiveSharingState(),
    val accessibilityEnabled: Boolean = false,
    val notificationsGranted: Boolean = true,
    val activityLogs: List<ActivityLogEntry> = emptyList(),
    val snackbarMessage: String? = null
)

class HostViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val prefsStore = HostPreferencesStore(appContext)
    private val apiClient = SupportApiClient()
    private val networkMonitor = NetworkMonitor(appContext)

    private val _uiState = MutableStateFlow(HostUiState())
    val uiState: StateFlow<HostUiState> = _uiState.asStateFlow()

    private var heartbeatJob: Job? = null
    private var sessionPollJob: Job? = null
    private var logSequence = 0L

    init {
        networkMonitor.start()

        viewModelScope.launch {
            prefsStore.ensureDeviceUid()
        }

        viewModelScope.launch {
            prefsStore.settingsFlow.collect { settings ->
                val isPlaceholderUrl = settings.serverUrl.contains("your-domain.com", ignoreCase = true)
                _uiState.update { state ->
                    state.copy(
                        settingsLoaded = true,
                        settings = settings,
                        serverStatus = if (isPlaceholderUrl && state.serverStatus is ServerConnectionStatus.Unconfigured) {
                            ServerConnectionStatus.Unconfigured
                        } else {
                            state.serverStatus
                        }
                    )
                }
                if (!isPlaceholderUrl && settings.deviceUid.isNotBlank() && heartbeatJob == null) {
                    startHeartbeatLoop()
                }
            }
        }

        viewModelScope.launch {
            networkMonitor.networkType.collect { net ->
                _uiState.update { it.copy(networkType = net) }
            }
        }

        viewModelScope.launch {
            SupportSessionRuntime.state.collect { live ->
                val previousActive = _uiState.value.liveSharing.isSharingActive
                _uiState.update {
                    it.copy(
                        liveSharing = live,
                        accessibilityEnabled = live.isAccessibilityServiceConnected ||
                            SupportAccessibilityService.isEnabledInSystemSettings(appContext)
                    )
                }
                if (previousActive && !live.isSharingActive && !live.lastStopReason.isNullOrBlank()) {
                    appendLog("Session stopped: ${live.lastStopReason}", isWarning = true)
                    _uiState.update {
                        it.copy(
                            sessionStatusLabel = "ended",
                            pendingRequest = null,
                            snackbarMessage = live.lastStopReason
                        )
                    }
                }
            }
        }

        refreshPermissionStates(notificationsGranted = true)
    }

    fun refreshPermissionStates(notificationsGranted: Boolean) {
        val accEnabled = SupportAccessibilityService.isEnabledInSystemSettings(appContext)
        _uiState.update {
            it.copy(
                accessibilityEnabled = accEnabled,
                notificationsGranted = notificationsGranted
            )
        }
    }

    fun completeOnboardingConsent() {
        viewModelScope.launch {
            prefsStore.setConsentAccepted(true)
            appendLog("Transparency & consent acknowledged")
        }
    }

    fun saveAndTestServerConfig(serverUrl: String, apiSecretKey: String, deviceName: String) {
        val normalized = apiClient.normalizeEndpoint(serverUrl)
        viewModelScope.launch {
            prefsStore.saveServerConfig(normalized, apiSecretKey, deviceName)
            _uiState.update { it.copy(serverStatus = ServerConnectionStatus.Checking) }

            if (!networkMonitor.isOnline) {
                val msg = "Device is offline. Connect to Wi-Fi or mobile data first."
                _uiState.update {
                    it.copy(
                        serverStatus = ServerConnectionStatus.Error(msg),
                        snackbarMessage = msg
                    )
                }
                return@launch
            }

            when (val res = apiClient.checkHealth(normalized, apiSecretKey)) {
                is ApiResult.Success -> {
                    val h = res.data
                    prefsStore.updateDynamicServerConfig(
                        frameIntervalMs = h.frameIntervalMs,
                        commandPollIntervalMs = h.commandPollIntervalMs,
                        appUpdateNotice = h.appUpdateNotice
                    )
                    _uiState.update {
                        it.copy(
                            serverStatus = ServerConnectionStatus.Connected(
                                latencyMs = res.latencyMs,
                                databaseConnected = h.databaseConnected,
                                serverTimeUtc = h.serverTimeUtc,
                                defaultTrialDays = h.defaultTrialDays
                            ),
                            snackbarMessage = "PHP + MySQL server connected (${res.latencyMs}ms)"
                        )
                    }
                    appendLog("Connected to PHP backend (${res.latencyMs}ms, MySQL OK)")
                    registerHostDeviceNow()
                    startHeartbeatLoop()
                }

                is ApiResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            serverStatus = ServerConnectionStatus.Error(res.message),
                            snackbarMessage = res.message
                        )
                    }
                    appendLog("Server connection failed: ${res.message}", isWarning = true)
                }
            }
        }
    }

    fun registerHostDeviceNow() {
        viewModelScope.launch {
            val s = _uiState.value.settings
            val uid = s.deviceUid.ifBlank { prefsStore.ensureDeviceUid() }
            if (s.serverUrl.contains("your-domain.com", ignoreCase = true) || !networkMonitor.isOnline) {
                return@launch
            }
            when (
                val res = apiClient.registerDevice(
                    baseUrl = s.serverUrl,
                    apiKey = s.apiSecretKey,
                    deviceUid = uid,
                    deviceName = s.deviceName,
                    deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
                    osVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                    networkType = networkMonitor.networkType.value.apiLabel
                )
            ) {
                is ApiResult.Success -> {
                    res.data.config?.let { cfg ->
                        prefsStore.updateDynamicServerConfig(
                            frameIntervalMs = cfg.frameIntervalMs,
                            commandPollIntervalMs = cfg.commandPollIntervalMs,
                            appUpdateNotice = cfg.appUpdateNotice
                        )
                    }
                    _uiState.update { it.copy(isRegisteredWithServer = true) }
                    appendLog("Host registered as ${s.deviceName}")
                }

                is ApiResult.Failure -> {
                    _uiState.update { it.copy(isRegisteredWithServer = false) }
                    appendLog("Device registration failed: ${res.message}", isWarning = true)
                }
            }
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                val s = _uiState.value.settings
                if (networkMonitor.isOnline && s.deviceUid.isNotBlank() && !s.serverUrl.contains("your-domain.com", ignoreCase = true)) {
                    when (
                        val hb = apiClient.sendHeartbeat(
                            baseUrl = s.serverUrl,
                            apiKey = s.apiSecretKey,
                            deviceUid = s.deviceUid,
                            networkType = networkMonitor.networkType.value.apiLabel
                        )
                    ) {
                        is ApiResult.Success -> {
                            prefsStore.updateDynamicServerConfig(
                                frameIntervalMs = hb.data.frameIntervalMs,
                                commandPollIntervalMs = hb.data.commandPollIntervalMs,
                                appUpdateNotice = hb.data.appUpdateNotice
                            )
                            _uiState.update { state ->
                                val updatedStatus = when (val cur = state.serverStatus) {
                                    is ServerConnectionStatus.Connected -> cur.copy(
                                        latencyMs = hb.latencyMs,
                                        serverTimeUtc = hb.data.serverTimeUtc
                                    )
                                    else -> ServerConnectionStatus.Connected(
                                        latencyMs = hb.latencyMs,
                                        databaseConnected = true,
                                        serverTimeUtc = hb.data.serverTimeUtc,
                                        defaultTrialDays = 3
                                    )
                                }
                                state.copy(serverStatus = updatedStatus)
                            }
                        }

                        is ApiResult.Failure -> {
                            // Keep last status unless persistent error
                        }
                    }
                }
                delay(15_000L)
            }
        }
    }

    fun createNewSupportSession() {
        viewModelScope.launch {
            val s = _uiState.value.settings
            if (!networkMonitor.isOnline) {
                _uiState.update { it.copy(snackbarMessage = "Internet connection is required to create a session.") }
                return@launch
            }
            if (s.serverUrl.contains("your-domain.com", ignoreCase = true)) {
                _uiState.update { it.copy(snackbarMessage = "Configure your PHP backend URL in the PHP Server tab first.") }
                return@launch
            }

            if (_uiState.value.liveSharing.isSharingActive) {
                stopActiveSharing("Starting new support session")
            }

            _uiState.update { it.copy(isCreatingSession = true, pendingRequest = null) }
            val uid = s.deviceUid.ifBlank { prefsStore.ensureDeviceUid() }

            // Ensure device is registered before creating session
            val reg = apiClient.registerDevice(
                baseUrl = s.serverUrl,
                apiKey = s.apiSecretKey,
                deviceUid = uid,
                deviceName = s.deviceName,
                deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
                osVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                networkType = networkMonitor.networkType.value.apiLabel
            )
            if (reg is ApiResult.Failure) {
                _uiState.update {
                    it.copy(
                        isCreatingSession = false,
                        serverStatus = ServerConnectionStatus.Error(reg.message),
                        snackbarMessage = reg.message
                    )
                }
                appendLog("Session setup failed: ${reg.message}", isWarning = true)
                return@launch
            }

            when (val res = apiClient.createSession(s.serverUrl, s.apiSecretKey, uid)) {
                is ApiResult.Success -> {
                    val created = res.data
                    _uiState.update {
                        it.copy(
                            isCreatingSession = false,
                            isRegisteredWithServer = true,
                            sessionCode = created.sessionCode,
                            pinCode = created.pinCode,
                            sessionStatusLabel = created.status,
                            pendingRequest = null,
                            snackbarMessage = "Session ${created.sessionCode} ready for pairing"
                        )
                    }
                    appendLog("Created Session ${created.sessionCode} (6-digit PIN generated)")
                    startSessionPolling(created.sessionCode)
                }

                is ApiResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            isCreatingSession = false,
                            snackbarMessage = res.message
                        )
                    }
                    appendLog("Failed to create session: ${res.message}", isWarning = true)
                }
            }
        }
    }

    private fun startSessionPolling(sessionCode: String) {
        sessionPollJob?.cancel()
        sessionPollJob = viewModelScope.launch {
            while (isActive) {
                val state = _uiState.value
                if (state.liveSharing.isSharingActive || state.sessionCode != sessionCode) {
                    delay(2500L)
                    continue
                }
                if (networkMonitor.isOnline) {
                    when (val res = apiClient.getSessionStatus(state.settings.serverUrl, state.settings.apiSecretKey, sessionCode)) {
                        is ApiResult.Success -> {
                            val st = res.data
                            when (st.status) {
                                "pending_approval" -> {
                                    val sub = st.viewerSubscription
                                    val subLabel = when (sub?.status) {
                                        "trial" -> "3-Day Free Trial (${sub.remainingDays}d left)"
                                        "active" -> "${sub.planTitle ?: "Active Plan"} (${sub.remainingDays}d left)"
                                        else -> "Subscription Required"
                                    }
                                    val incoming = PendingViewerRequest(
                                        sessionCode = st.sessionCode,
                                        viewerName = st.viewerName?.ifBlank { "Support Agent" } ?: "Support Agent",
                                        viewerEmail = st.viewerEmail.orEmpty(),
                                        subscriptionLabel = subLabel,
                                        subscriptionEntitled = st.viewerEntitled
                                    )
                                    val wasAlreadyShowing = _uiState.value.pendingRequest?.sessionCode == incoming.sessionCode
                                    _uiState.update {
                                        it.copy(
                                            sessionStatusLabel = "pending_approval",
                                            pendingRequest = incoming
                                        )
                                    }
                                    if (!wasAlreadyShowing) {
                                        appendLog("Connection request from ${incoming.viewerName}")
                                    }
                                }

                                "waiting" -> {
                                    _uiState.update {
                                        it.copy(sessionStatusLabel = "waiting", pendingRequest = null)
                                    }
                                }

                                "declined", "ended", "expired" -> {
                                    _uiState.update {
                                        it.copy(sessionStatusLabel = st.status, pendingRequest = null)
                                    }
                                    break
                                }
                            }
                        }

                        is ApiResult.Failure -> {
                            // Silently retry on transient poll error
                        }
                    }
                }
                delay(2200L)
            }
        }
    }

    fun onAcceptConfirmedWithProjection(resultCode: Int, projectionData: Intent) {
        val pending = _uiState.value.pendingRequest ?: return
        val s = _uiState.value.settings

        viewModelScope.launch {
            val resp = apiClient.respondToConnection(
                baseUrl = s.serverUrl,
                apiKey = s.apiSecretKey,
                sessionCode = pending.sessionCode,
                deviceUid = s.deviceUid,
                accept = true,
                assistedControlEnabled = s.assistedControlAllowed
            )

            when (resp) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            pendingRequest = null,
                            sessionStatusLabel = "active",
                            snackbarMessage = "Remote support active with ${pending.viewerName}"
                        )
                    }
                    appendLog("Approved ${pending.viewerName} — Screen sharing started")

                    val serviceIntent = Intent(appContext, ScreenShareForegroundService::class.java).apply {
                        action = ScreenShareForegroundService.ACTION_START_SHARING
                        putExtra(ScreenShareForegroundService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(ScreenShareForegroundService.EXTRA_PROJECTION_DATA, projectionData)
                        putExtra(ScreenShareForegroundService.EXTRA_SERVER_URL, s.serverUrl)
                        putExtra(ScreenShareForegroundService.EXTRA_API_KEY, s.apiSecretKey)
                        putExtra(ScreenShareForegroundService.EXTRA_SESSION_CODE, pending.sessionCode)
                        putExtra(ScreenShareForegroundService.EXTRA_DEVICE_UID, s.deviceUid)
                        putExtra(ScreenShareForegroundService.EXTRA_VIEWER_NAME, pending.viewerName)
                        putExtra(ScreenShareForegroundService.EXTRA_VIEWER_SUB_LABEL, pending.subscriptionLabel)
                        putExtra(ScreenShareForegroundService.EXTRA_QUALITY_MODE, "balanced")
                        putExtra(ScreenShareForegroundService.EXTRA_ASSISTED_ALLOWED, s.assistedControlAllowed)
                        putExtra(ScreenShareForegroundService.EXTRA_FRAME_INTERVAL_MS, s.frameIntervalMs)
                        putExtra(ScreenShareForegroundService.EXTRA_COMMAND_POLL_MS, s.commandPollIntervalMs)
                    }
                    ContextCompat.startForegroundService(appContext, serviceIntent)
                }

                is ApiResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            pendingRequest = null,
                            snackbarMessage = "Could not accept request: ${resp.message}"
                        )
                    }
                    appendLog("Accept failed: ${resp.message}", isWarning = true)
                }
            }
        }
    }

    fun onMediaProjectionCancelled() {
        _uiState.update {
            it.copy(snackbarMessage = "Screen capture permission was cancelled. Connection not started.")
        }
        appendLog("Screen capture prompt cancelled by user", isWarning = true)
    }

    fun declineIncomingRequest() {
        val pending = _uiState.value.pendingRequest ?: return
        val s = _uiState.value.settings
        viewModelScope.launch {
            apiClient.respondToConnection(
                baseUrl = s.serverUrl,
                apiKey = s.apiSecretKey,
                sessionCode = pending.sessionCode,
                deviceUid = s.deviceUid,
                accept = false,
                assistedControlEnabled = false
            )
            _uiState.update {
                it.copy(
                    pendingRequest = null,
                    sessionStatusLabel = "declined",
                    snackbarMessage = "Declined connection from ${pending.viewerName}"
                )
            }
            appendLog("Declined connection from ${pending.viewerName}", isWarning = true)
        }
    }

    fun setAssistedControlPreference(allowed: Boolean) {
        viewModelScope.launch {
            prefsStore.setAssistedControlAllowed(allowed)
            SupportSessionRuntime.setAssistedGesturesAllowed(allowed)
            val code = _uiState.value.sessionCode
            val s = _uiState.value.settings
            if (_uiState.value.liveSharing.isSharingActive && code.isNotBlank()) {
                apiClient.updateSessionAssistedControl(s.serverUrl, s.apiSecretKey, code, allowed)
            }
            appendLog(if (allowed) "Assisted gestures enabled" else "Assisted gestures paused by user")
        }
    }

    fun stopActiveSharing(reason: String = "Stopped by Host user") {
        val stopIntent = ScreenShareForegroundService.createStopIntent(appContext, reason)
        appContext.startService(stopIntent)
        val code = _uiState.value.sessionCode
        val s = _uiState.value.settings
        if (code.isNotBlank() && !s.serverUrl.contains("your-domain.com", ignoreCase = true)) {
            viewModelScope.launch {
                apiClient.endSession(s.serverUrl, s.apiSecretKey, code, reason)
            }
        }
        _uiState.update {
            it.copy(
                sessionStatusLabel = "ended",
                pendingRequest = null
            )
        }
    }

    fun showMessage(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun consumeSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun appendLog(title: String, isWarning: Boolean = false) {
        val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val entry = ActivityLogEntry(
            id = ++logSequence,
            timestamp = formatter.format(Date()),
            title = title,
            isWarning = isWarning
        )
        _uiState.update { state ->
            state.copy(activityLogs = (listOf(entry) + state.activityLogs).take(12))
        }
    }

    override fun onCleared() {
        networkMonitor.stop()
        heartbeatJob?.cancel()
        sessionPollJob?.cancel()
        super.onCleared()
    }
}
