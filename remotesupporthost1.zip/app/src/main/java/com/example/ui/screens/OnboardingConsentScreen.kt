package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.LocalStatusPalette

@Composable
fun OnboardingConsentScreen(
    isStandaloneOnboarding: Boolean,
    accessibilityEnabled: Boolean,
    notificationsGranted: Boolean,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onAcceptConsent: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalStatusPalette.current
    var consentChecked by remember { mutableStateOf(!isStandaloneOnboarding) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        MaterialTheme.colorScheme.background
                    )
                )
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 620.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Banner
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shadowElevation = 1.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Column {
                            Text(
                                text = stringResource(R.string.onboarding_title),
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "RemoteSupportHost • PHP + MySQL",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Text(
                        text = stringResource(R.string.onboarding_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Permission Disclosures
            PermissionDisclosureCard(
                icon = Icons.Rounded.ScreenShare,
                title = "Screen Sharing (MediaProjection)",
                description = "Only starts after you tap 'Accept & Share Screen' on an incoming request AND approve Android's system screen capture dialog. Nothing is captured in the background.",
                statusLabel = "Requested Per Session",
                isReady = true
            )

            PermissionDisclosureCard(
                icon = Icons.Rounded.AccessibilityNew,
                title = "Assisted Gestures (Accessibility Service)",
                description = "Allows an approved support agent to perform tap, swipe, and Back/Home gestures strictly while a live session is active. Never reads passwords or runs without active sharing.",
                statusLabel = if (accessibilityEnabled) "Enabled" else "Optional • Not Enabled",
                isReady = accessibilityEnabled,
                actionLabel = if (accessibilityEnabled) "Review Settings" else "Enable Accessibility",
                actionTestTag = "onboarding_accessibility_button",
                onAction = onOpenAccessibilitySettings
            )

            PermissionDisclosureCard(
                icon = Icons.Rounded.NotificationsActive,
                title = "Persistent Active-Session Notification",
                description = "Displays an always-visible banner ('Remote Support Active — Tap to Stop') whenever sharing is active so you can disconnect instantly from any app.",
                statusLabel = if (notificationsGranted) "Allowed" else "Permission Needed",
                isReady = notificationsGranted,
                actionLabel = if (!notificationsGranted) "Allow Notifications" else null,
                actionTestTag = "onboarding_notification_button",
                onAction = onRequestNotificationPermission
            )

            PermissionDisclosureCard(
                icon = Icons.Rounded.Wifi,
                title = "Internet & PHP/MySQL Server Sync",
                description = "Relays encrypted pairing codes, screen frames, and assisted commands strictly through your configured PHP + MySQL server over Wi-Fi or mobile data. Zero Firebase services are used.",
                statusLabel = "Standard Permission",
                isReady = true
            )

            PermissionDisclosureCard(
                icon = Icons.Rounded.Visibility,
                title = "Always Visible & User-Removable",
                description = "RemoteSupportHost always keeps its launcher icon visible and works with standard Android App Info & Uninstall settings — no hidden icons or uninstall restrictions.",
                statusLabel = "Verified Transparent",
                isReady = true
            )

            if (isStandaloneOnboarding) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = consentChecked,
                            onCheckedChange = { consentChecked = it },
                            modifier = Modifier.testTag("consent_acknowledge_checkbox")
                        )
                        Text(
                            text = "I understand that screen sharing and assisted gestures require my explicit approval for each session and can be stopped at any moment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }

                Button(
                    onClick = onAcceptConsent,
                    enabled = consentChecked,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("onboarding_continue_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        text = stringResource(R.string.onboarding_cta),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                StatusPillBadge(
                    label = "Consent Acknowledged • Full User Control Active",
                    containerColor = palette.activeContainer,
                    contentColor = palette.onActiveContainer,
                    icon = Icons.Rounded.CheckCircle
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PermissionDisclosureCard(
    icon: ImageVector,
    title: String,
    description: String,
    statusLabel: String,
    isReady: Boolean,
    actionLabel: String? = null,
    actionTestTag: String? = null,
    onAction: (() -> Unit)? = null
) {
    val palette = LocalStatusPalette.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusPillBadge(
                    label = statusLabel,
                    containerColor = if (isReady) palette.activeContainer else palette.pendingContainer,
                    contentColor = if (isReady) palette.onActiveContainer else palette.onPendingContainer,
                    showDot = true
                )
                if (actionLabel != null && onAction != null) {
                    OutlinedButton(
                        onClick = onAction,
                        shape = RoundedCornerShape(12.dp),
                        modifier = if (actionTestTag != null) Modifier.testTag(actionTestTag) else Modifier
                    ) {
                        Text(
                            text = actionLabel,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}
