package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.NetworkType
import com.example.ui.ActivityLogEntry
import com.example.ui.HostUiState
import com.example.ui.ServerConnectionStatus
import com.example.ui.components.StatusPillBadge
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalStatusPalette

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HostDashboardScreen(
    uiState: HostUiState,
    onCreateNewSession: () -> Unit,
    onStopActiveSession: () -> Unit,
    onToggleAssistedControl: (Boolean) -> Unit,
    onOpenServerSettings: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onCopiedCredentials: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalStatusPalette.current
    val clipboard = LocalClipboardManager.current
    val isLive = uiState.liveSharing.isSharingActive
    val isPlaceholderServer = uiState.settings.serverUrl.contains("your-domain.com", ignoreCase = true)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Identity & Live Status Chips
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "${uiState.settings.deviceName} • Host Device",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    StatusPillBadge(
                        label = when {
                            isLive -> "LIVE SHARING"
                            uiState.sessionStatusLabel == "pending_approval" -> "APPROVAL NEEDED"
                            uiState.sessionStatusLabel == "waiting" -> "READY TO PAIR"
                            else -> "STANDBY"
                        },
                        containerColor = when {
                            isLive -> palette.stopContainer
                            uiState.sessionStatusLabel == "pending_approval" -> palette.pendingContainer
                            uiState.sessionStatusLabel == "waiting" -> palette.activeContainer
                            else -> MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        contentColor = when {
                            isLive -> palette.onStopContainer
                            uiState.sessionStatusLabel == "pending_approval" -> palette.onPendingContainer
                            uiState.sessionStatusLabel == "waiting" -> palette.onActiveContainer
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        showDot = true
                    )
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Network Pill
                    val netIcon = when (uiState.networkType) {
                        NetworkType.WIFI -> Icons.Rounded.Wifi
                        NetworkType.CELLULAR -> Icons.Rounded.SignalCellularAlt
                        NetworkType.OTHER -> Icons.Rounded.Wifi
                        NetworkType.OFFLINE -> Icons.Rounded.WifiOff
                    }
                    StatusPillBadge(
                        label = uiState.networkType.displayLabel,
                        containerColor = if (uiState.networkType != NetworkType.OFFLINE) palette.activeContainer else palette.stopContainer,
                        contentColor = if (uiState.networkType != NetworkType.OFFLINE) palette.onActiveContainer else palette.onStopContainer,
                        icon = netIcon
                    )

                    // PHP Backend Pill
                    val (serverLabel, serverBg, serverFg, serverIcon) = when (val st = uiState.serverStatus) {
                        is ServerConnectionStatus.Connected -> Quadruple(
                            "PHP Server • ${st.latencyMs}ms",
                            palette.activeContainer,
                            palette.onActiveContainer,
                            Icons.Rounded.CloudDone
                        )

                        is ServerConnectionStatus.Checking -> Quadruple(
                            "Checking PHP Server...",
                            palette.pendingContainer,
                            palette.onPendingContainer,
                            Icons.Rounded.Refresh
                        )

                        is ServerConnectionStatus.Error -> Quadruple(
                            "Server Offline",
                            palette.stopContainer,
                            palette.onStopContainer,
                            Icons.Rounded.CloudOff
                        )

                        ServerConnectionStatus.Unconfigured -> Quadruple(
                            "Server Not Set",
                            palette.pendingContainer,
                            palette.onPendingContainer,
                            Icons.Rounded.Settings
                        )
                    }
                    StatusPillBadge(
                        label = serverLabel,
                        containerColor = serverBg,
                        contentColor = serverFg,
                        icon = serverIcon
                    )

                    // Accessibility Pill
                    StatusPillBadge(
                        label = if (uiState.accessibilityEnabled) "Assisted Touch Ready" else "View-Only Mode",
                        containerColor = if (uiState.accessibilityEnabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                        contentColor = if (uiState.accessibilityEnabled) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        icon = Icons.Rounded.AccessibilityNew
                    )
                }
            }

            // Dynamic Admin Update Notice Banner (synced from MySQL app_server_config)
            if (uiState.settings.appUpdateNotice.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Campaign,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = uiState.settings.appUpdateNotice,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Prompt to configure PHP Backend if still placeholder
            if (isPlaceholderServer) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = palette.pendingContainer,
                    border = BorderStroke(1.dp, palette.pending.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Warning,
                                contentDescription = null,
                                tint = palette.onPendingContainer,
                                modifier = Modifier.size(22.dp)
                            )
                            Column {
                                Text(
                                    text = "Configure PHP + MySQL URL",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.onPendingContainer
                                )
                                Text(
                                    text = "Point RemoteSupportHost to your hosted api.php endpoint to generate live pairing codes.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.onPendingContainer.copy(alpha = 0.85f)
                                )
                            }
                        }
                        TextButton(
                            onClick = onOpenServerSettings,
                            modifier = Modifier.testTag("banner_configure_server_button")
                        ) {
                            Text("Configure", fontWeight = FontWeight.Bold, color = palette.onPendingContainer)
                        }
                    }
                }
            }

            // HERO CARD: Session Pairing Credentials (Session ID + 6-Digit Temporary PIN)
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.32f),
                                    MaterialTheme.colorScheme.surface
                                )
                            )
                        )
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Key,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Support Session Pairing",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Share this ID & temporary PIN only with a trusted agent",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (uiState.sessionCode.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Session ID Box
                            Surface(
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "SESSION ID",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = uiState.sessionCode,
                                        fontFamily = JetBrainsMonoFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 19.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.testTag("session_code_value")
                                    )
                                }
                            }

                            // 6-Digit PIN Box
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "6-DIGIT PIN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    val spacedPin = if (uiState.pinCode.length == 6) {
                                        "${uiState.pinCode.substring(0, 3)} ${uiState.pinCode.substring(3)}"
                                    } else {
                                        uiState.pinCode
                                    }
                                    Text(
                                        text = spacedPin,
                                        fontFamily = JetBrainsMonoFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 19.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.testTag("session_pin_value")
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    clipboard.setText(
                                        AnnotatedString("Session ID: ${uiState.sessionCode} | PIN: ${uiState.pinCode}")
                                    )
                                    onCopiedCredentials()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("copy_credentials_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentCopy,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.btn_copy_credentials))
                            }

                            Button(
                                onClick = onCreateNewSession,
                                enabled = !uiState.isCreatingSession && !isLive,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("regenerate_session_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                if (uiState.isCreatingSession) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(stringResource(R.string.btn_regenerate_session))
                                }
                            }
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ScreenShare,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(34.dp)
                                )
                                Text(
                                    text = "No Active Support Code",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Generate a temporary Session ID & 6-digit PIN when you are ready to receive assistance. Nothing is shared until you explicitly approve.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = onCreateNewSession,
                            enabled = !uiState.isCreatingSession,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("create_session_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            if (uiState.isCreatingSession) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Generating Session...")
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Key,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.btn_generate_session),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            // LIVE SESSION CONTROLS & TELEMETRY (Visible when screen sharing is active)
            if (isLive) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.5.dp, palette.stop.copy(alpha = 0.45f)),
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Active Session Controls",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Agent: ${uiState.liveSharing.viewerName} • ${uiState.liveSharing.viewerSubscriptionLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPillBadge(
                                label = uiState.liveSharing.qualityMode.uppercase(),
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            TelemetryTile(
                                label = "Frames Sent",
                                value = uiState.liveSharing.framesSent.toString(),
                                modifier = Modifier.weight(1f)
                            )
                            TelemetryTile(
                                label = "Assisted Actions",
                                value = uiState.liveSharing.commandsExecuted.toString(),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.TouchApp,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text(
                                            text = "Allow Assisted Gestures",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (uiState.liveSharing.lastCommandLabel.isNotBlank()) {
                                                "Last action: ${uiState.liveSharing.lastCommandLabel}"
                                            } else {
                                                "Toggle off anytime for view-only sharing"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = uiState.liveSharing.assistedGesturesAllowed && uiState.accessibilityEnabled,
                                    onCheckedChange = onToggleAssistedControl,
                                    enabled = uiState.accessibilityEnabled,
                                    modifier = Modifier.testTag("live_assisted_toggle")
                                )
                            }
                        }

                        Button(
                            onClick = onStopActiveSession,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.stop,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("stop_remote_support_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.StopCircle,
                                contentDescription = null,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.btn_stop_support),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // PERMISSION & CONTROL READINESS CARD
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Permission Readiness",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AccessibilityNew,
                                contentDescription = null,
                                tint = if (uiState.accessibilityEnabled) palette.active else palette.pending
                            )
                            Column {
                                Text(
                                    text = "Assisted Gestures Service",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (uiState.accessibilityEnabled) {
                                        "Active for consented sessions only"
                                    } else {
                                        "Enable in Accessibility Settings for remote touch"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        TextButton(
                            onClick = onOpenAccessibilitySettings,
                            modifier = Modifier.testTag("dashboard_accessibility_button")
                        ) {
                            Text(if (uiState.accessibilityEnabled) "Manage" else "Enable")
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.NotificationsActive,
                                contentDescription = null,
                                tint = if (uiState.notificationsGranted) palette.active else palette.pending
                            )
                            Column {
                                Text(
                                    text = "Active Session Notification",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (uiState.notificationsGranted) {
                                        "Persistent stop indicator ready"
                                    } else {
                                        "Allow notifications to see persistent stop button"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (!uiState.notificationsGranted) {
                            TextButton(
                                onClick = onRequestNotificationPermission,
                                modifier = Modifier.testTag("dashboard_notification_button")
                            ) {
                                Text("Allow")
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Allowed",
                                tint = palette.active,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // TRANSPARENT ACTIVITY LOG
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Transparent Session Audit Log",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (uiState.activityLogs.isEmpty()) {
                        Text(
                            text = "Session pairing, approvals, and stop events will appear here with timestamps.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        uiState.activityLogs.forEach { entry ->
                            ActivityLogRow(entry = entry)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun TelemetryTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun ActivityLogRow(entry: ActivityLogEntry) {
    val palette = LocalStatusPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (entry.isWarning) palette.pending else palette.active)
        )
        Text(
            text = entry.timestamp,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = entry.title,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
