package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class StatusPalette(
    val active: Color = EmeraldActive,
    val activeContainer: Color = EmeraldContainer,
    val onActiveContainer: Color = OnEmeraldContainer,
    val pending: Color = AmberPending,
    val pendingContainer: Color = AmberContainer,
    val onPendingContainer: Color = OnAmberContainer,
    val stop: Color = CrimsonStop,
    val stopContainer: Color = CrimsonContainer,
    val onStopContainer: Color = OnCrimsonContainer
)

val LocalStatusPalette = staticCompositionLocalOf { StatusPalette() }

private val BrightLightColorScheme = lightColorScheme(
    primary = CobaltPrimary,
    onPrimary = Color.White,
    primaryContainer = CobaltContainer,
    onPrimaryContainer = OnCobaltContainer,
    secondary = SlateSecondary,
    onSecondary = Color.White,
    secondaryContainer = SlateSecondaryContainer,
    onSecondaryContainer = OnSlateSecondaryContainer,
    tertiary = EmeraldActive,
    onTertiary = Color.White,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = OnEmeraldContainer,
    error = CrimsonStop,
    onError = Color.White,
    errorContainer = CrimsonContainer,
    onErrorContainer = OnCrimsonContainer,
    background = CanvasWhite,
    onBackground = InkPrimary,
    surface = SurfacePureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SurfaceContainerLow,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = SurfacePureWhite,
    surfaceContainerLow = SurfaceContainerLow,
    surfaceContainer = SurfaceContainerLow,
    surfaceContainerHigh = SurfaceContainerHigh,
    outline = BorderSubtle,
    outlineVariant = BorderSubtle
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

/**
 * Enforces a bright, clean Material 3 Light Theme at all times (dark theme intentionally disabled).
 */
@Composable
fun RemoteSupportHostTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalStatusPalette provides StatusPalette()) {
        MaterialTheme(
            colorScheme = BrightLightColorScheme,
            typography = RemoteSupportTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
