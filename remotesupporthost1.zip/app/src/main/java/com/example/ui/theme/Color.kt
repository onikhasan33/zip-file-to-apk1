package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand — Authoritative Cobalt Trust Palette (Light Theme Only)
val CobaltPrimary = Color(0xFF0862FF)
val CobaltPrimaryDark = Color(0xFF0044B8)
val CobaltContainer = Color(0xFFE7F0FF)
val OnCobaltContainer = Color(0xFF002B75)

// Secondary — Calm Cerulean Slate
val SlateSecondary = Color(0xFF334E68)
val SlateSecondaryContainer = Color(0xFFE6EEF6)
val OnSlateSecondaryContainer = Color(0xFF102A43)

// Surfaces — Crisp Swiss Light Canvas
val CanvasWhite = Color(0xFFF6F8FC)
val SurfacePureWhite = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF0F4FA)
val SurfaceContainerHigh = Color(0xFFE6ECF5)
val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val BorderSubtle = Color(0xFFD8E1EE)

// Semantic Status Badges
val EmeraldActive = Color(0xFF059669)
val EmeraldContainer = Color(0xFFDCFCE7)
val OnEmeraldContainer = Color(0xFF065F46)

val AmberPending = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF92400E)

val CrimsonStop = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEE2E2)
val OnCrimsonContainer = Color(0xFF991B1B)
