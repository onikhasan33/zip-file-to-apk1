package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ApiResult<out T> {
    data class Success<T>(val data: T, val latencyMs: Long = 0L) : ApiResult<T>()
    data class Failure(
        val errorCode: String,
        val message: String,
        val httpCode: Int = 0
    ) : ApiResult<Nothing>()
}

class SupportApiClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    fun normalizeEndpoint(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) return ""
        val withScheme = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            trimmed
        } else {
            "https://$trimmed"
        }
        return if (withScheme.endsWith(".php", ignoreCase = true) || withScheme.contains("api.php")) {
            withScheme
        } else {
            withScheme.trimEnd('/') + "/api.php"
        }
    }

    private fun buildActionUrl(baseUrl: String, action: String, queryParams: Map<String, String> = emptyMap()): String? {
        val normalized = normalizeEndpoint(baseUrl)
        val parsed = normalized.toHttpUrlOrNull() ?: return null
        if (parsed.scheme != "http" && parsed.scheme != "https") return null
        val builder = parsed.newBuilder().setQueryParameter("action", action)
        queryParams.forEach { (k, v) -> builder.setQueryParameter(k, v) }
        return builder.build().toString()
    }

    private suspend inline fun <reified T> executeGet(
        baseUrl: String,
        apiKey: String,
        action: String,
        queryParams: Map<String, String> = emptyMap()
    ): ApiResult<T> = withContext(Dispatchers.IO) {
        val url = buildActionUrl(baseUrl, action, queryParams)
            ?: return@withContext ApiResult.Failure("invalid_url", "Enter a valid HTTP/HTTPS PHP api.php URL.")
        val reqBuilder = Request.Builder().url(url).get()
        if (apiKey.isNotBlank()) {
            reqBuilder.header("X-API-Key", apiKey.trim())
        }
        executeRequest(reqBuilder.build(), T::class.java)
    }

    private suspend inline fun <reified T> executePost(
        baseUrl: String,
        apiKey: String,
        action: String,
        bodyJson: JSONObject
    ): ApiResult<T> = withContext(Dispatchers.IO) {
        val url = buildActionUrl(baseUrl, action)
            ?: return@withContext ApiResult.Failure("invalid_url", "Enter a valid HTTP/HTTPS PHP api.php URL.")
        val requestBody = bodyJson.toString().toRequestBody(jsonMediaType)
        val reqBuilder = Request.Builder().url(url).post(requestBody)
        if (apiKey.isNotBlank()) {
            reqBuilder.header("X-API-Key", apiKey.trim())
        }
        executeRequest(reqBuilder.build(), T::class.java)
    }

    private fun <T> executeRequest(request: Request, clazz: Class<T>): ApiResult<T> {
        val started = System.currentTimeMillis()
        return try {
            client.newCall(request).execute().use { response ->
                val latency = (System.currentTimeMillis() - started).coerceAtLeast(1L)
                val rawBody = response.body?.string().orEmpty()
                if (rawBody.isBlank()) {
                    return ApiResult.Failure(
                        errorCode = "empty_response",
                        message = "Server returned an empty response (HTTP ${response.code}).",
                        httpCode = response.code
                    )
                }

                // Check server JSON error wrapper cleanly even on 4xx/5xx
                val errObj = runCatching { JSONObject(rawBody) }.getOrNull()
                if (!response.isSuccessful || (errObj != null && errObj.optBoolean("ok", true) == false)) {
                    val code = errObj?.optString("error").orEmpty().ifBlank { "http_${response.code}" }
                    val msg = errObj?.optString("message").orEmpty()
                        .ifBlank { "Server request failed (HTTP ${response.code})." }
                    return ApiResult.Failure(code, msg, response.code)
                }

                val adapter = moshi.adapter(clazz)
                val parsed = adapter.fromJson(rawBody)
                    ?: return ApiResult.Failure("parse_error", "Could not parse server JSON response.", response.code)
                ApiResult.Success(parsed, latency)
            }
        } catch (e: IOException) {
            ApiResult.Failure("network_error", e.localizedMessage ?: "Unable to reach PHP backend server.")
        } catch (e: Exception) {
            ApiResult.Failure("unexpected_error", e.localizedMessage ?: "Unexpected network error.")
        }
    }

    suspend fun checkHealth(baseUrl: String, apiKey: String): ApiResult<HealthResponse> =
        executeGet(baseUrl, apiKey, "health")

    suspend fun registerDevice(
        baseUrl: String,
        apiKey: String,
        deviceUid: String,
        deviceName: String,
        deviceModel: String,
        osVersion: String,
        networkType: String
    ): ApiResult<RegisterDeviceResponse> {
        val payload = JSONObject().apply {
            put("device_uid", deviceUid)
            put("device_name", deviceName)
            put("device_model", deviceModel)
            put("os_version", osVersion)
            put("app_role", "host")
            put("network_type", networkType)
        }
        return executePost(baseUrl, apiKey, "register_device", payload)
    }

    suspend fun sendHeartbeat(
        baseUrl: String,
        apiKey: String,
        deviceUid: String,
        networkType: String
    ): ApiResult<HeartbeatResponse> {
        val payload = JSONObject().apply {
            put("device_uid", deviceUid)
            put("network_type", networkType)
        }
        return executePost(baseUrl, apiKey, "heartbeat", payload)
    }

    suspend fun createSession(
        baseUrl: String,
        apiKey: String,
        deviceUid: String
    ): ApiResult<CreateSessionResponse> {
        val payload = JSONObject().apply {
            put("device_uid", deviceUid)
        }
        return executePost(baseUrl, apiKey, "create_session", payload)
    }

    suspend fun getSessionStatus(
        baseUrl: String,
        apiKey: String,
        sessionCode: String
    ): ApiResult<SessionStatusResponse> =
        executeGet(baseUrl, apiKey, "session_status", mapOf("session_code" to sessionCode))

    suspend fun respondToConnection(
        baseUrl: String,
        apiKey: String,
        sessionCode: String,
        deviceUid: String,
        accept: Boolean,
        assistedControlEnabled: Boolean
    ): ApiResult<BasicResponse> {
        val payload = JSONObject().apply {
            put("session_code", sessionCode)
            put("device_uid", deviceUid)
            put("decision", if (accept) "accept" else "decline")
            put("assisted_control_enabled", assistedControlEnabled)
        }
        return executePost(baseUrl, apiKey, "respond_connection", payload)
    }

    suspend fun updateSessionAssistedControl(
        baseUrl: String,
        apiKey: String,
        sessionCode: String,
        assistedControlEnabled: Boolean
    ): ApiResult<BasicResponse> {
        val payload = JSONObject().apply {
            put("session_code", sessionCode)
            put("assisted_control_enabled", assistedControlEnabled)
        }
        return executePost(baseUrl, apiKey, "update_session_settings", payload)
    }

    suspend fun endSession(
        baseUrl: String,
        apiKey: String,
        sessionCode: String,
        reason: String
    ): ApiResult<BasicResponse> {
        val payload = JSONObject().apply {
            put("session_code", sessionCode)
            put("reason", reason)
        }
        return executePost(baseUrl, apiKey, "end_session", payload)
    }

    suspend fun uploadFrame(
        baseUrl: String,
        apiKey: String,
        sessionCode: String,
        deviceUid: String,
        frameBase64: String,
        width: Int,
        height: Int,
        frameSeq: Long
    ): ApiResult<UploadFrameResponse> {
        val payload = JSONObject().apply {
            put("session_code", sessionCode)
            put("device_uid", deviceUid)
            put("frame_base64", frameBase64)
            put("width", width)
            put("height", height)
            put("frame_seq", frameSeq)
        }
        return executePost(baseUrl, apiKey, "upload_frame", payload)
    }

    suspend fun pollCommands(
        baseUrl: String,
        apiKey: String,
        sessionCode: String,
        deviceUid: String
    ): ApiResult<PollCommandsResponse> =
        executeGet(
            baseUrl = baseUrl,
            apiKey = apiKey,
            action = "poll_commands",
            queryParams = mapOf(
                "session_code" to sessionCode,
                "device_uid" to deviceUid
            )
        )
}
