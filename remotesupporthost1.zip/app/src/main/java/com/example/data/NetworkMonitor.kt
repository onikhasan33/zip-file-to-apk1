package com.example.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class NetworkType(val apiLabel: String, val displayLabel: String) {
    WIFI("wifi", "Wi-Fi"),
    CELLULAR("cellular", "Mobile Data"),
    OTHER("other", "Connected"),
    OFFLINE("offline", "Offline")
}

class NetworkMonitor(context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _networkType = MutableStateFlow(readCurrentNetworkType())
    val networkType: StateFlow<NetworkType> = _networkType.asStateFlow()

    val isOnline: Boolean
        get() = _networkType.value != NetworkType.OFFLINE

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _networkType.value = readCurrentNetworkType()
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            _networkType.value = readCurrentNetworkType()
        }

        override fun onLost(network: Network) {
            _networkType.value = readCurrentNetworkType()
        }
    }

    private var registered = false

    fun start() {
        if (registered) return
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, callback)
            registered = true
            _networkType.value = readCurrentNetworkType()
        } catch (_: Exception) {
            _networkType.value = readCurrentNetworkType()
        }
    }

    fun stop() {
        if (!registered) return
        try {
            connectivityManager.unregisterNetworkCallback(callback)
        } catch (_: Exception) {
            // Safe ignore
        } finally {
            registered = false
        }
    }

    fun readCurrentNetworkType(): NetworkType {
        val activeNetwork = connectivityManager.activeNetwork ?: return NetworkType.OFFLINE
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return NetworkType.OFFLINE
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            return NetworkType.OFFLINE
        }
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkType.CELLULAR
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.OTHER
            else -> NetworkType.OTHER
        }
    }
}
