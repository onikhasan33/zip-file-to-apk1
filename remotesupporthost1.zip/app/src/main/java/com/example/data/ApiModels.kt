package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "status") val status: String = "unknown",
    @Json(name = "database_connected") val databaseConnected: Boolean = false,
    @Json(name = "server_time_utc") val serverTimeUtc: String = "",
    @Json(name = "frame_interval_ms") val frameIntervalMs: Int = 650,
    @Json(name = "command_poll_interval_ms") val commandPollIntervalMs: Int = 350,
    @Json(name = "default_trial_days") val defaultTrialDays: Int = 3,
    @Json(name = "trial_enabled") val trialEnabled: Boolean = true,
    @Json(name = "app_update_notice") val appUpdateNotice: String = "",
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class DynamicConfigDto(
    @Json(name = "frame_interval_ms") val frameIntervalMs: Int = 650,
    @Json(name = "command_poll_interval_ms") val commandPollIntervalMs: Int = 350,
    @Json(name = "app_update_notice") val appUpdateNotice: String = ""
)

@JsonClass(generateAdapter = true)
data class RegisterDeviceResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "config") val config: DynamicConfigDto? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class HeartbeatResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "server_time_utc") val serverTimeUtc: String = "",
    @Json(name = "frame_interval_ms") val frameIntervalMs: Int = 650,
    @Json(name = "command_poll_interval_ms") val commandPollIntervalMs: Int = 350,
    @Json(name = "app_update_notice") val appUpdateNotice: String = "",
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateSessionResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "session_id") val sessionId: Long = 0L,
    @Json(name = "session_code") val sessionCode: String = "",
    @Json(name = "pin_code") val pinCode: String = "",
    @Json(name = "status") val status: String = "waiting",
    @Json(name = "quality_mode") val qualityMode: String = "balanced",
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class ViewerSubscriptionInfo(
    @Json(name = "status") val status: String = "expired",
    @Json(name = "is_entitled") val isEntitled: Boolean = false,
    @Json(name = "plan_title") val planTitle: String? = null,
    @Json(name = "expires_at") val expiresAt: String? = null,
    @Json(name = "remaining_seconds") val remainingSeconds: Long = 0L,
    @Json(name = "remaining_days") val remainingDays: Int = 0
)

@JsonClass(generateAdapter = true)
data class SessionStatusResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "session_id") val sessionId: Long = 0L,
    @Json(name = "session_code") val sessionCode: String = "",
    @Json(name = "status") val status: String = "waiting",
    @Json(name = "quality_mode") val qualityMode: String = "balanced",
    @Json(name = "assisted_control_enabled") val assistedControlEnabled: Boolean = true,
    @Json(name = "host_device_name") val hostDeviceName: String? = null,
    @Json(name = "host_online") val hostOnline: Boolean = false,
    @Json(name = "viewer_name") val viewerName: String? = null,
    @Json(name = "viewer_email") val viewerEmail: String? = null,
    @Json(name = "viewer_entitled") val viewerEntitled: Boolean = false,
    @Json(name = "viewer_subscription") val viewerSubscription: ViewerSubscriptionInfo? = null,
    @Json(name = "end_reason") val endReason: String? = null,
    @Json(name = "frame_interval_ms") val frameIntervalMs: Int = 650,
    @Json(name = "command_poll_interval_ms") val commandPollIntervalMs: Int = 350,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class BasicResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "status") val status: String? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class UploadFrameResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "frame_id") val frameId: Long = 0L,
    @Json(name = "quality_mode") val qualityMode: String = "balanced",
    @Json(name = "status") val status: String = "active",
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class CommandPayloadDto(
    @Json(name = "x") val x: Float? = null,
    @Json(name = "y") val y: Float? = null,
    @Json(name = "x1") val x1: Float? = null,
    @Json(name = "y1") val y1: Float? = null,
    @Json(name = "x2") val x2: Float? = null,
    @Json(name = "y2") val y2: Float? = null,
    @Json(name = "duration_ms") val durationMs: Long? = null
)

@JsonClass(generateAdapter = true)
data class RemoteCommandDto(
    @Json(name = "id") val id: Long = 0L,
    @Json(name = "command_type") val commandType: String = "",
    @Json(name = "payload") val payload: CommandPayloadDto? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PollCommandsResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "session_status") val sessionStatus: String = "active",
    @Json(name = "quality_mode") val qualityMode: String = "balanced",
    @Json(name = "assisted_control_enabled") val assistedControlEnabled: Boolean = true,
    @Json(name = "viewer_entitled") val viewerEntitled: Boolean = true,
    @Json(name = "commands") val commands: List<RemoteCommandDto> = emptyList(),
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)
