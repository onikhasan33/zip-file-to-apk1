package com.example.data

import android.content.Context
import android.os.Build
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.hostDataStore: DataStore<Preferences> by preferencesDataStore(name = "remote_support_host_prefs")

data class HostSettings(
    val deviceUid: String = "",
    val deviceName: String = defaultDeviceLabel(),
    val serverUrl: String = DEFAULT_PHP_API_URL,
    val apiSecretKey: String = "",
    val consentAccepted: Boolean = false,
    val assistedControlAllowed: Boolean = true,
    val frameIntervalMs: Int = 650,
    val commandPollIntervalMs: Int = 350,
    val appUpdateNotice: String = ""
) {
    companion object {
        const val DEFAULT_PHP_API_URL = "https://your-domain.com/backend/api.php"

        fun defaultDeviceLabel(): String {
            val manufacturer = Build.MANUFACTURER.orEmpty().replaceFirstChar { it.uppercase() }
            val model = Build.MODEL.orEmpty()
            return if (model.startsWith(manufacturer, ignoreCase = true)) {
                model.ifBlank { "Android Host" }
            } else {
                "$manufacturer $model".trim().ifBlank { "Android Host" }
            }
        }
    }
}

class HostPreferencesStore(private val context: Context) {

    private object Keys {
        val DEVICE_UID = stringPreferencesKey("device_uid")
        val DEVICE_NAME = stringPreferencesKey("device_name")
        val SERVER_URL = stringPreferencesKey("server_url")
        val API_SECRET_KEY = stringPreferencesKey("api_secret_key")
        val CONSENT_ACCEPTED = booleanPreferencesKey("consent_accepted")
        val ASSISTED_CONTROL_ALLOWED = booleanPreferencesKey("assisted_control_allowed")
        val FRAME_INTERVAL_MS = intPreferencesKey("frame_interval_ms")
        val COMMAND_POLL_INTERVAL_MS = intPreferencesKey("command_poll_interval_ms")
        val APP_UPDATE_NOTICE = stringPreferencesKey("app_update_notice")
    }

    val settingsFlow: Flow<HostSettings> = context.hostDataStore.data.map { prefs ->
        HostSettings(
            deviceUid = prefs[Keys.DEVICE_UID].orEmpty(),
            deviceName = prefs[Keys.DEVICE_NAME] ?: HostSettings.defaultDeviceLabel(),
            serverUrl = prefs[Keys.SERVER_URL] ?: HostSettings.DEFAULT_PHP_API_URL,
            apiSecretKey = prefs[Keys.API_SECRET_KEY].orEmpty(),
            consentAccepted = prefs[Keys.CONSENT_ACCEPTED] ?: false,
            assistedControlAllowed = prefs[Keys.ASSISTED_CONTROL_ALLOWED] ?: true,
            frameIntervalMs = (prefs[Keys.FRAME_INTERVAL_MS] ?: 650).coerceIn(250, 3000),
            commandPollIntervalMs = (prefs[Keys.COMMAND_POLL_INTERVAL_MS] ?: 350).coerceIn(200, 2000),
            appUpdateNotice = prefs[Keys.APP_UPDATE_NOTICE].orEmpty()
        )
    }

    suspend fun ensureDeviceUid(): String {
        val current = context.hostDataStore.data.first()[Keys.DEVICE_UID]
        if (!current.isNullOrBlank()) return current
        val generated = "HOST-${UUID.randomUUID().toString().take(12).uppercase()}"
        context.hostDataStore.edit { it[Keys.DEVICE_UID] = generated }
        return generated
    }

    suspend fun setConsentAccepted(accepted: Boolean) {
        context.hostDataStore.edit { it[Keys.CONSENT_ACCEPTED] = accepted }
    }

    suspend fun saveServerConfig(serverUrl: String, apiSecretKey: String, deviceName: String) {
        context.hostDataStore.edit {
            it[Keys.SERVER_URL] = serverUrl.trim()
            it[Keys.API_SECRET_KEY] = apiSecretKey.trim()
            if (deviceName.isNotBlank()) {
                it[Keys.DEVICE_NAME] = deviceName.trim()
            }
        }
    }

    suspend fun setAssistedControlAllowed(allowed: Boolean) {
        context.hostDataStore.edit { it[Keys.ASSISTED_CONTROL_ALLOWED] = allowed }
    }

    suspend fun updateDynamicServerConfig(
        frameIntervalMs: Int,
        commandPollIntervalMs: Int,
        appUpdateNotice: String
    ) {
        context.hostDataStore.edit {
            it[Keys.FRAME_INTERVAL_MS] = frameIntervalMs.coerceIn(250, 3000)
            it[Keys.COMMAND_POLL_INTERVAL_MS] = commandPollIntervalMs.coerceIn(200, 2000)
            it[Keys.APP_UPDATE_NOTICE] = appUpdateNotice.trim()
        }
    }
}
